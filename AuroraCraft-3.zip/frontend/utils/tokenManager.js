class TokenManager {
  async getUserTokenBalance(userId) {
    try {
      // Check current user in localStorage first
      const currentUserStr = localStorage.getItem('currentUser');
      if (currentUserStr) {
        const currentUser = JSON.parse(currentUserStr);
        if (currentUser.id === userId || currentUser._id === userId) {
          return currentUser.tokens || 0;
        }
      }
      
      // Otherwise fetch from API
      const user = await getCurrentUser();
      return user.tokens || 0;
    } catch (error) {
      console.error('Failed to get token balance:', error);
      return 0;
    }
  }

  async isAdmin(userId) {
    try {
      // Check current user in localStorage first
      const currentUserStr = localStorage.getItem('currentUser');
      if (currentUserStr) {
        const currentUser = JSON.parse(currentUserStr);
        return currentUser.role === 'admin';
      }
      return false;
    } catch (error) {
      return false;
    }
  }

  async getModelTokenCost(modelId) {
    try {
      // Get all models and find the one we need
      const modelsData = await trickleListObjects('ai_model', 1000, true);
      const model = modelsData.items.find(m => m._id === modelId || m.objectId === modelId);
      if (model) {
        return model.TokenAmount || model.objectData?.TokenAmount || 1;
      }
      return 1;
    } catch (error) {
      console.error('Failed to get model token cost:', error);
      return 1;
    }
  }

  async getContextInterval() {
    try {
      const settings = await trickleListObjects('system_settings', 1, true);
      if (settings.items.length > 0) {
        return settings.items[0].objectData.TokensPerContextInterval || 10;
      }
      return 10;
    } catch (error) {
      console.error('Failed to get context interval:', error);
      return 10;
    }
  }

  async canUserSendMessage(userId, modelId) {
    // First check if admin (don't need userId for this)
    if (await this.isAdmin()) {
      return { allowed: true, isAdmin: true };
    }

    const balance = await this.getUserTokenBalance(userId);
    const tokenAmount = await this.getModelTokenCost(modelId);
    
    return { 
      allowed: balance >= tokenAmount, 
      balance,
      tokenCost: tokenAmount,
      isAdmin: false 
    };
  }

  async deductTokens(userId, sessionId, modelId, promptLength, responseLength) {
    try {
      if (await this.isAdmin()) {
        return { success: true, isAdmin: true };
      }

      // For non-admins, we let the backend handle token deduction through the AI API
      // This is just a placeholder that returns success
      // The actual token deduction happens in the /api/ai/invoke endpoint
      return { 
        success: true, 
        newBalance: await this.getUserTokenBalance(userId),
        tokensUsed: 0,
        contextCount: 0,
        nextDeductionAt: await this.getContextInterval()
      };

      if (tokensToDeduct > 0) {
        await trickleCreateObject('token_transaction', {
          userId,
          sessionId: sessionId || 'unknown',
          modelId: modelId || 'unknown',
          tokensUsed: tokensToDeduct,
          promptLength: promptLength || 0,
          responseLength: responseLength || 0,
          transactionType: 'usage'
        });
      }

      return { 
        success: true, 
        newBalance,
        tokensUsed: tokensToDeduct,
        contextCount,
        nextDeductionAt: contextInterval
      };
    } catch (error) {
      console.error('Token deduction failed:', error);
      return { success: false, error: error.message };
    }
  }

  async addTokens(userId, amount, transactionType = 'admin_grant') {
    try {
      // Use the API endpoint to update tokens
      const response = await apiCall(`/users/${userId}/tokens`, {
        method: 'PUT',
        body: JSON.stringify({ tokens: amount })
      });
      
      return { success: true, newBalance: amount };
    } catch (error) {
      console.error('Token addition failed:', error);
      return { success: false, error: error.message };
    }
  }

  async getTransactionHistory(userId, limit = 50) {
    try {
      // Get transactions from API
      const transactions = await apiCall('/transactions');
      return transactions.items || [];
    } catch (error) {
      console.error('Failed to get transaction history:', error);
      return [];
    }
  }
}

const tokenManager = new TokenManager();
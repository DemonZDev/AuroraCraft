// AuroraCraft API Service
const API_BASE_URL = window.location.hostname === 'localhost' 
  ? 'http://localhost:8001/api' 
  : '/api';

// Auth helpers
function getAuthToken() {
  return localStorage.getItem('authToken');
}

function setAuthToken(token) {
  localStorage.setItem('authToken', token);
  return token;
}

function removeAuthToken() {
  localStorage.removeItem('authToken');
}

function getAuthHeaders() {
  const token = getAuthToken();
  return token ? { 'Authorization': `Bearer ${token}` } : {};
}

// Generic API call wrapper
async function apiCall(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`;
  const config = {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...getAuthHeaders(),
      ...options.headers
    }
  };

  try {
    const response = await fetch(url, config);
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.detail || `HTTP error! status: ${response.status}`);
    }
    
    return data;
  } catch (error) {
    console.error(`API Error [${endpoint}]:`, error);
    throw error;
  }
}

// Replace Trickle functions with API calls

// List objects from collection
async function trickleListObjects(objectType, limit = 100, includeData = true) {
  // Map object types to correct API endpoints
  const endpointMap = {
    'user': '/users',
    'ai_provider': '/providers',
    'ai_model': '/models',
    'system_settings': '/settings',
    'session': '/sessions'
  };
  
  // Handle session with userId prefix
  if (objectType.startsWith('session:')) {
    const endpoint = '/sessions';
    const data = await apiCall(endpoint);
    return {
      items: data.items.map(item => ({
        objectId: item._id,
        objectData: item,
        ...item
      })),
      total: data.total || data.items.length
    };
  }
  
  const endpoint = endpointMap[objectType] || `/${objectType}`;
  const data = await apiCall(endpoint);
  
  // Handle system_settings response (single object, not array)
  if (objectType === 'system_settings') {
    if (data._id) {
      return {
        items: [{
          objectId: data._id,
          objectData: data,
          ...data
        }],
        total: 1
      };
    }
    return { items: [], total: 0 };
  }
  
  return {
    items: data.items.map(item => ({
      objectId: item._id,
      objectData: item,
      ...item
    })),
    total: data.total || data.items.length
  };
}

// Get single object
async function trickleGetObject(objectType, objectId) {
  // Handle session objects with userId prefix
  if (objectType.startsWith('session:')) {
    const endpoint = `/sessions/${objectId}`;
    const data = await apiCall(endpoint);
    return {
      objectId: data._id,
      objectData: data,
      ...data
    };
  }
  
  const endpoint = `/${objectType}/${objectId}`;
  const data = await apiCall(endpoint);
  return {
    objectId: data._id,
    objectData: data,
    ...data
  };
}

// Create object
async function trickleCreateObject(objectType, objectData) {
  // Map object types to correct API endpoints
  const endpointMap = {
    'user': '/auth/register',
    'ai_provider': '/providers',
    'ai_model': '/models',
    'system_settings': '/settings',
    'session': '/sessions'
  };
  
  // Handle session objects with userId prefix
  if (objectType.startsWith('session:')) {
    const endpoint = `/sessions`;
    const data = await apiCall(endpoint, {
      method: 'POST',
      body: JSON.stringify(objectData)
    });
    return {
      objectId: data.id,
      ...data
    };
  }
  
  // Handle user creation differently (uses /auth/register endpoint)
  if (objectType === 'user') {
    const endpoint = '/auth/register';
    const data = await apiCall(endpoint, {
      method: 'POST',
      body: JSON.stringify(objectData)
    });
    return {
      objectId: data.user.id,
      ...data
    };
  }
  
  const endpoint = endpointMap[objectType] || `/${objectType}`;
  const data = await apiCall(endpoint, {
    method: 'POST',
    body: JSON.stringify(objectData)
  });
  return {
    objectId: data.id || data._id,
    ...data
  };
}

// Update object
async function trickleUpdateObject(objectType, objectId, updates) {
  // Map object types to correct API endpoints
  const endpointMap = {
    'user': '/users',
    'ai_provider': '/providers',
    'ai_model': '/models',
    'system_settings': '/settings',
    'session': '/sessions'
  };
  
  // Handle session objects with userId prefix
  if (objectType.startsWith('session:')) {
    const endpoint = `/sessions/${objectId}`;
    await apiCall(endpoint, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
    return { success: true };
  }
  
  const endpoint = endpointMap[objectType] ? `${endpointMap[objectType]}/${objectId}` : `/${objectType}/${objectId}`;
  await apiCall(endpoint, {
    method: 'PUT',
    body: JSON.stringify(updates)
  });
  return { success: true };
}

// Delete object
async function trickleDeleteObject(objectType, objectId) {
  // Map object types to correct API endpoints
  const endpointMap = {
    'user': '/users',
    'ai_provider': '/providers',
    'ai_model': '/models',
    'system_settings': '/settings',
    'session': '/sessions'
  };
  
  // Handle session objects with userId prefix
  if (objectType.startsWith('session:')) {
    const endpoint = `/sessions/${objectId}`;
    await apiCall(endpoint, {
      method: 'DELETE'
    });
    return { success: true };
  }
  
  const endpoint = endpointMap[objectType] ? `${endpointMap[objectType]}/${objectId}` : `/${objectType}/${objectId}`;
  await apiCall(endpoint, {
    method: 'DELETE'
  });
  return { success: true };
}

// AI Agent invocation
async function invokeAIAgent(systemPrompt, userPrompt, modelId = null) {
  const endpoint = '/ai/invoke';
  const data = await apiCall(endpoint, {
    method: 'POST',
    body: JSON.stringify({
      systemPrompt,
      userPrompt,
      modelId
    })
  });
  return data.content;
}

// Auth functions
async function login(email, password) {
  const data = await apiCall('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  });
  setAuthToken(data.token);
  // Store user data with consistent structure
  localStorage.setItem('currentUser', JSON.stringify(data.user));
  return data;
}

async function register(username, email, password) {
  const data = await apiCall('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ username, email, password })
  });
  setAuthToken(data.token);
  // Store user data with consistent structure
  localStorage.setItem('currentUser', JSON.stringify(data.user));
  return data;
}

async function getCurrentUser() {
  return await apiCall('/auth/me');
}

function logout() {
  removeAuthToken();
  localStorage.removeItem('currentUser');
  window.location.href = '/login.html';
}

// Check if user is logged in
function isLoggedIn() {
  return !!getAuthToken();
}

// Export all functions for global use
window.apiCall = apiCall;
window.trickleListObjects = trickleListObjects;
window.trickleGetObject = trickleGetObject;
window.trickleCreateObject = trickleCreateObject;
window.trickleUpdateObject = trickleUpdateObject;
window.trickleDeleteObject = trickleDeleteObject;
window.invokeAIAgent = invokeAIAgent;
window.login = login;
window.register = register;
window.getCurrentUser = getCurrentUser;
window.logout = logout;
window.isLoggedIn = isLoggedIn;
window.getAuthToken = getAuthToken;
window.setAuthToken = setAuthToken;

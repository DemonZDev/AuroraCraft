function ChatInterface() {
  try {
    const [messages, setMessages] = React.useState([]);
    const [input, setInput] = React.useState('');
    const [isLoading, setIsLoading] = React.useState(false);
    const [showConfig, setShowConfig] = React.useState(false);
    const [uploadedFiles, setUploadedFiles] = React.useState([]);
    const [currentSession, setCurrentSession] = React.useState(null);
    const [currentView, setCurrentView] = React.useState('chat');
    const [selectedFile, setSelectedFile] = React.useState(null);
    const [projectFiles, setProjectFiles] = React.useState([]);
    const [tokenBalance, setTokenBalance] = React.useState(0);
    const [isAdmin, setIsAdmin] = React.useState(false);
    const [config, setConfig] = React.useState({
      model: '',
      mode: 'agent',
      creatorType: 'minecraft-plugin',
      software: 'paper',
      phase: null,
      autoApprove: false
    });
    const [agentState, setAgentState] = React.useState('idle');
    const [currentPlan, setCurrentPlan] = React.useState(null);
    const [availableModels, setAvailableModels] = React.useState([]);

    React.useEffect(() => {
      loadAvailableModels();
      loadSessionFromURL();
      loadTokenBalance();
    }, []);

    const loadTokenBalance = async () => {
      const user = localStorage.getItem('currentUser');
      if (user) {
        const userData = JSON.parse(user);
        const adminStatus = await tokenManager.isAdmin(userData.objectId);
        setIsAdmin(adminStatus);
        
        if (!adminStatus) {
          const balance = await tokenManager.getUserTokenBalance(userData.objectId);
          setTokenBalance(balance);
        }
      }
    };

    const loadSessionFromURL = async () => {
      const urlParams = new URLSearchParams(window.location.search);
      const sessionId = urlParams.get('session');
      const userId = urlParams.get('userId');
      if (sessionId) {
        try {
          const user = localStorage.getItem('currentUser');
          if (user) {
            const userData = JSON.parse(user);
            const targetUserId = userId || userData.objectId;
            const session = await trickleGetObject(`session:${targetUserId}`, sessionId);
            setCurrentSession(session);
            if (session.objectData.messages) {
              setMessages(session.objectData.messages);
            }
            if (session.objectData.model) {
              setConfig(prev => ({...prev, model: session.objectData.model}));
            }
            if (session.objectData.creatorType) {
              setConfig(prev => ({...prev, creatorType: session.objectData.creatorType}));
            }
            if (session.objectData.software) {
              setConfig(prev => ({...prev, software: session.objectData.software}));
            }
          }
        } catch (error) {
          console.error('Failed to load session:', error);
        }
      }
    };

    const loadAvailableModels = async () => {
      try {
        const models = await getActiveModels();
        setAvailableModels(models);
        if (models.length > 0) {
          setConfig(prev => ({
            ...prev, 
            model: prev.model || models[0].modelId
          }));
        }
      } catch (error) {
        console.error('Failed to load models:', error);
        setAvailableModels([]);
      }
    };
    const chatEndRef = React.useRef(null);
    const fileInputRef = React.useRef(null);

    React.useEffect(() => {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleFileUpload = (e) => {
      const files = Array.from(e.target.files);
      setUploadedFiles(prev => [...prev, ...files]);
    };

    const removeFile = (index) => {
      setUploadedFiles(prev => prev.filter((_, i) => i !== index));
    };

    const handleEnhance = async () => {
      if (!input.trim() || isLoading) return;
      setIsLoading(true);
      try {
        const enhanced = await enhancePrompt(input);
        setInput(enhanced);
      } catch (error) {
        console.error('Enhancement error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    const handleSend = async () => {
      if (!input.trim() || isLoading) return;
      
      const user = localStorage.getItem('currentUser');
      if (!user) {
        window.location.href = 'login.html';
        return;
      }
      const userData = JSON.parse(user);

      if (!config.model) {
        setMessages(prev => [...prev, { 
          role: 'system', 
          content: 'Please select an AI model before sending a message.' 
        }]);
        setIsLoading(false);
        return;
      }

      const canSend = await tokenManager.canUserSendMessage(userData.objectId, config.model);
      if (!canSend.allowed) {
        setMessages(prev => [...prev, { 
          role: 'system', 
          content: `❌ Insufficient tokens! You need ${canSend.tokenCost} tokens to send a message with this model.\n\nCurrent balance: ${canSend.balance} tokens\n\nPlease contact an administrator to add more tokens to your account.` 
        }]);
        return;
      }

      const userMessage = { role: 'user', content: input };
      setMessages(prev => [...prev, userMessage]);
      setInput('');
      setIsLoading(true);

      try {
        if (!currentSession) {
          const user = localStorage.getItem('currentUser');
          if (user) {
            const userData = JSON.parse(user);
            const sessionName = input.substring(0, 50) + (input.length > 50 ? '...' : '');
            const newSession = await trickleCreateObject(`session:${userData.objectId}`, {
              name: sessionName,
              model: config.model,
              mode: config.mode,
              software: config.software,
              creatorType: config.creatorType,
              messageCount: 0,
              messages: [userMessage]
            });
            setCurrentSession(newSession);
          }
        }

        const chatHistory = messages.map(m => ({ role: m.role, content: m.content }));
        
        let response;
        try {
          response = await createMinecraftPluginAgent(input, config.mode, config.software, chatHistory, config.model);
        } catch (error) {
          console.error('AI invocation failed:', error);
          const errorMessage = error.message || 'Unknown error occurred';
          setMessages(prev => [...prev, { 
            role: 'ai', 
            content: `I encountered an error while processing your request:\n\n${errorMessage}\n\nPlease check:\n1. Your AI model is properly configured in Admin panel\n2. The model provider is active\n3. API credentials are correct\n\nTry selecting a different model or contact support if the issue persists.` 
          }]);
          setIsLoading(false);
          return;
        }
        
        const aiMessage = { role: 'ai', content: response };
        const updatedMessages = [...messages, userMessage, aiMessage];
        setMessages(updatedMessages);

        const tokenResult = await tokenManager.deductTokens(
          userData.objectId,
          currentSession?.objectId,
          config.model,
          input.length,
          response.length
        );

        if (tokenResult.success && !tokenResult.isAdmin) {
          setTokenBalance(tokenResult.newBalance);
        }

        if (currentSession) {
          await trickleUpdateObject(`session:${userData.objectId}`, currentSession.objectId, {
            ...currentSession.objectData,
            messageCount: (currentSession.objectData.messageCount || 0) + 2,
            messages: updatedMessages,
            lastUpdated: new Date().toISOString()
          });
        }
      } catch (error) {
        console.error('Send message error:', error);
        setMessages(prev => [...prev, { 
          role: 'ai', 
          content: 'An unexpected error occurred. Please try again or contact support if the issue persists.' 
        }]);
      } finally {
        setIsLoading(false);
      }
    };

    return (
      <div className="h-full flex flex-col bg-[var(--bg-darker)]" data-name="chat-interface" data-file="components/chat/ChatInterface.js">
        <div className="border-b border-[var(--border-color)] bg-[var(--bg-dark)] p-4">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[var(--primary-color)] rounded-lg flex items-center justify-center">
                  <div className="icon-sparkles text-xl text-white"></div>
                </div>
                <div>
                  <h1 className="font-bold">AuroraCraft</h1>
                  <p className="text-xs text-[var(--text-secondary)]">AI Plugin Assistant</p>
                </div>
              </div>
              {!isAdmin && (
                <div className="flex items-center gap-2 px-3 py-1 bg-[var(--secondary-color)] rounded-lg border border-[var(--border-color)]">
                  <div className="icon-coins text-base text-yellow-400"></div>
                  <span className="text-sm font-medium">{tokenBalance} tokens</span>
                </div>
              )}
              
              <div className="hidden md:flex items-center gap-2 ml-4">
                <button
                  onClick={() => setCurrentView('chat')}
                  className={`px-4 py-2 rounded-lg text-sm transition-all ${
                    currentView === 'chat' 
                      ? 'bg-[var(--primary-color)] text-white' 
                      : 'bg-[var(--secondary-color)] text-[var(--text-secondary)] hover:text-white'
                  }`}
                >
                  <div className="icon-message-circle text-base inline-block mr-2"></div>
                  Chat
                </button>
                <button
                  onClick={() => setCurrentView('codebase')}
                  className={`px-4 py-2 rounded-lg text-sm transition-all ${
                    currentView === 'codebase' 
                      ? 'bg-[var(--primary-color)] text-white' 
                      : 'bg-[var(--secondary-color)] text-[var(--text-secondary)] hover:text-white'
                  }`}
                >
                  <div className="icon-code-2 text-base inline-block mr-2"></div>
                  Codebase
                </button>
              </div>
            </div>
            
            <button onClick={() => window.location.href = 'index.html'} className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]">
              <div className="icon-x text-xl"></div>
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-hidden">
          {currentView === 'chat' ? (
            <div className="h-full overflow-y-auto p-6">
              <div className="max-w-4xl mx-auto">
            {messages.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-[var(--primary-color)] bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <div className="icon-sparkles text-4xl text-[var(--primary-color)]"></div>
                </div>
                <h2 className="text-2xl font-bold mb-3">Welcome to AuroraCraft</h2>
                <p className="text-[var(--text-secondary)] mb-8 max-w-md mx-auto">
                  Start building your Minecraft plugin. Describe what you want to create and I'll help you every step of the way.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-w-2xl mx-auto">
                  {[
                    'Create an economy plugin with shops',
                    'Build a custom command system',
                    'Plan a complete PvP arena plugin',
                    'Test my teleportation plugin code'
                  ].map((suggestion, i) => (
                    <button
                      key={i}
                      onClick={() => setInput(suggestion)}
                      className="p-4 bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-lg text-left hover:border-[var(--primary-color)] transition-all"
                    >
                      <div className="text-sm">{suggestion}</div>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {messages.map((msg, index) => {
                  const userData = JSON.parse(localStorage.getItem('currentUser') || '{}');
                  const aiName = localStorage.getItem('aiName') || 'AuroraCraft';
                  const aiAvatar = localStorage.getItem('aiAvatar') || null;
                  
                  return (
                    <div key={index} className={`flex gap-4 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                      {msg.role === 'ai' && (
                        <div className="flex flex-col items-center gap-1 flex-shrink-0">
                          <div className="w-10 h-10 bg-[var(--primary-color)] rounded-lg flex items-center justify-center overflow-hidden">
                            {aiAvatar ? (
                              <img src={aiAvatar} alt="AI" className="w-full h-full object-cover" />
                            ) : (
                              <div className="icon-bot text-base text-white"></div>
                            )}
                          </div>
                          <span className="text-xs text-[var(--text-secondary)]">{aiName}</span>
                        </div>
                      )}
                      <div className={`px-4 py-3 rounded-lg max-w-2xl ${
                        msg.role === 'user' 
                          ? 'bg-[var(--primary-color)] text-white' 
                          : 'bg-[var(--bg-dark)] border border-[var(--border-color)]'
                      }`}>
                        <div className="whitespace-pre-wrap">{msg.content}</div>
                      </div>
                      {msg.role === 'user' && (
                        <div className="flex flex-col items-center gap-1 flex-shrink-0">
                          <div className="w-10 h-10 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center overflow-hidden">
                            {userData.objectData?.avatar ? (
                              <img src={userData.objectData.avatar} alt="User" className="w-full h-full object-cover" />
                            ) : (
                              <div className="icon-user text-base text-white"></div>
                            )}
                          </div>
                          <span className="text-xs text-[var(--text-secondary)]">{userData.objectData?.username || 'User'}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
                {isLoading && (() => {
                  const aiName = localStorage.getItem('aiName') || 'AuroraCraft';
                  const aiAvatar = localStorage.getItem('aiAvatar') || null;
                  return (
                    <div className="flex gap-4">
                      <div className="flex flex-col items-center gap-1 flex-shrink-0">
                        <div className="w-10 h-10 bg-[var(--primary-color)] rounded-lg flex items-center justify-center overflow-hidden">
                          {aiAvatar ? (
                            <img src={aiAvatar} alt="AI" className="w-full h-full object-cover" />
                          ) : (
                            <div className="icon-bot text-base text-white"></div>
                          )}
                        </div>
                        <span className="text-xs text-[var(--text-secondary)]">{aiName}</span>
                      </div>
                    <div className="px-4 py-3 bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-lg">
                      <div className="flex gap-2">
                        <div className="w-2 h-2 bg-[var(--text-secondary)] rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-[var(--text-secondary)] rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                        <div className="w-2 h-2 bg-[var(--text-secondary)] rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                      </div>
                      </div>
                    </div>
                  );
                })()}
                <div ref={chatEndRef} />
              </div>
            )}
              </div>
            </div>
          ) : (
            <div className="h-full flex">
              <div className="w-64 border-r border-[var(--border-color)] bg-[var(--bg-dark)] flex flex-col">
                <div className="p-4 border-b border-[var(--border-color)]">
                  <h3 className="font-bold text-sm">Project Files</h3>
                </div>
                <div className="flex-1 overflow-y-auto p-2">
                  {projectFiles.length === 0 ? (
                    <div className="text-center py-8 px-4 text-[var(--text-secondary)] text-sm">
                      No files yet. Start chatting to generate code!
                    </div>
                  ) : (
                    <div className="space-y-1">
                      {projectFiles.map((file, index) => (
                        <button
                          key={index}
                          onClick={() => setSelectedFile(file)}
                          className={`w-full text-left px-3 py-2 rounded text-sm flex items-center gap-2 transition-all ${
                            selectedFile?.path === file.path
                              ? 'bg-[var(--primary-color)] text-white'
                              : 'hover:bg-[var(--bg-darker)] text-[var(--text-secondary)]'
                          }`}
                        >
                          <div className="icon-file-text text-base"></div>
                          <span className="truncate">{file.name}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex-1 flex flex-col bg-[var(--bg-darker)]">
                {selectedFile ? (
                  <>
                    <div className="p-4 border-b border-[var(--border-color)] flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="icon-file-code text-lg text-[var(--primary-color)]"></div>
                        <span className="font-medium">{selectedFile.name}</span>
                      </div>
                      <div className="text-xs text-[var(--text-secondary)]">{selectedFile.path}</div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-6">
                      <pre className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-lg p-4 text-sm font-mono overflow-x-auto">
                        <code>{selectedFile.content}</code>
                      </pre>
                    </div>
                  </>
                ) : (
                  <div className="flex-1 flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-xl flex items-center justify-center mx-auto mb-4">
                        <div className="icon-file-code text-2xl text-[var(--primary-color)]"></div>
                      </div>
                      <h3 className="text-lg font-bold mb-2">No File Selected</h3>
                      <p className="text-[var(--text-secondary)] text-sm">Select a file from the sidebar to view its code</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="border-t border-[var(--border-color)] bg-[var(--bg-dark)] p-4">
          <div className="max-w-4xl mx-auto">
            {/* Desktop Config Options - Hidden on Mobile */}
            <div className="hidden md:grid md:grid-cols-4 gap-3 mb-3">
              <select 
                value={config.model}
                onChange={(e) => setConfig({...config, model: e.target.value})}
                className="px-3 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg text-sm"
              >
                {availableModels.length === 0 ? (
                  <option>No models available</option>
                ) : (
                  availableModels.map(model => (
                    <option key={model.modelId} value={model.modelId}>
                      {model.modelName} {model.tags?.includes('Recommended') && '⭐'}
                    </option>
                  ))
                )}
              </select>
              
              <select 
                value={config.mode}
                onChange={(e) => setConfig({...config, mode: e.target.value})}
                className="px-3 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg text-sm"
              >
                <option value="agent">Agent Mode</option>
                <option value="chat">Chat Mode</option>
                <option value="plan">Plan Mode</option>
                <option value="test">Test Mode</option>
              </select>
              
              <select 
                value={config.creatorType}
                onChange={(e) => setConfig({...config, creatorType: e.target.value})}
                disabled={currentSession !== null}
                className={`px-3 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg text-sm ${currentSession ? 'opacity-60 cursor-not-allowed' : ''}`}
              >
                <option value="minecraft-plugin">Minecraft Plugin</option>
                <option value="minecraft-mod" disabled>Minecraft Mod (Soon)</option>
                <option value="discord-bot" disabled>Discord Bot (Soon)</option>
              </select>
              
              <select 
                value={config.software}
                onChange={(e) => setConfig({...config, software: e.target.value})}
                className="px-3 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg text-sm"
              >
                <option value="paper">Paper</option>
                <option value="spigot">Spigot</option>
                <option value="bukkit">Bukkit</option>
                <option value="purpur">Purpur</option>
              </select>
            </div>

            {/* Mobile Config Panel */}
            {showConfig && (
              <div className="md:hidden grid grid-cols-1 gap-3 mb-3 pb-3 border-b border-[var(--border-color)]">
              <select 
                value={config.model}
                onChange={(e) => setConfig({...config, model: e.target.value})}
                className="px-3 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg text-sm"
              >
                {availableModels.length === 0 ? (
                  <option>No models available</option>
                ) : (
                  availableModels.map(model => (
                    <option key={model.modelId} value={model.modelId}>
                      {model.modelName} {model.tags?.includes('Recommended') && '⭐'}
                    </option>
                  ))
                )}
              </select>
                
                <select 
                  value={config.mode}
                  onChange={(e) => setConfig({...config, mode: e.target.value})}
                  className="px-3 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg text-sm"
                >
                  <option value="agent">Agent Mode</option>
                  <option value="chat">Chat Mode</option>
                  <option value="plan">Plan Mode</option>
                  <option value="test">Test Mode</option>
                </select>
                
                <select 
                  value={config.creatorType}
                  onChange={(e) => setConfig({...config, creatorType: e.target.value})}
                  disabled={currentSession !== null}
                  className={`px-3 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg text-sm ${currentSession ? 'opacity-60 cursor-not-allowed' : ''}`}
                >
                  <option value="minecraft-plugin">Minecraft Plugin</option>
                  <option value="minecraft-mod" disabled>Minecraft Mod (Soon)</option>
                  <option value="discord-bot" disabled>Discord Bot (Soon)</option>
                </select>
                
                <select 
                  value={config.software}
                  onChange={(e) => setConfig({...config, software: e.target.value})}
                  className="px-3 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg text-sm"
                >
                  <option value="paper">Paper</option>
                  <option value="spigot">Spigot</option>
                  <option value="bukkit">Bukkit</option>
                  <option value="purpur">Purpur</option>
                </select>
              </div>
            )}

            {/* Uploaded Files Display */}
            {uploadedFiles.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-3">
                {uploadedFiles.map((file, index) => (
                  <div key={index} className="flex items-center gap-2 px-3 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg text-sm">
                    <div className="icon-file text-base text-[var(--primary-color)]"></div>
                    <span className="max-w-[150px] truncate">{file.name}</span>
                    <button onClick={() => removeFile(index)} className="text-[var(--text-secondary)] hover:text-red-400">
                      <div className="icon-x text-sm"></div>
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Input Area */}
            <div className="flex gap-2">
              <div className="flex flex-col gap-2 shrink-0">
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept="image/*,.pdf,.txt,.java,.yml,.yaml,.json,.xml"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-10 h-10 md:w-12 md:h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center hover:bg-opacity-80 transition-all"
                  title="Upload files"
                >
                  <div className="icon-paperclip text-lg text-white"></div>
                </button>
                <button
                  onClick={() => setShowConfig(!showConfig)}
                  className="md:hidden w-10 h-10 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center hover:bg-opacity-80 transition-all"
                  title="Settings"
                >
                  <div className="icon-settings text-lg text-white"></div>
                </button>
                <button
                  onClick={() => setCurrentView(currentView === 'chat' ? 'codebase' : 'chat')}
                  className="md:hidden w-10 h-10 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center hover:bg-opacity-80 transition-all"
                  title="Toggle View"
                >
                  <div className={`icon-${currentView === 'chat' ? 'code-2' : 'message-circle'} text-lg text-white`}></div>
                </button>
              </div>
              
              <div className="flex-1 flex flex-col gap-2 min-w-0">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())}
                  placeholder="Describe your plugin idea..."
                  className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg resize-none focus:outline-none focus:border-[var(--primary-color)] min-h-[80px]"
                  rows="2"
                  disabled={isLoading}
                />
                <div className="flex gap-2 w-full">
                  <button
                    onClick={handleEnhance}
                    disabled={!input.trim() || isLoading}
                    className="flex-1 min-w-0 px-3 md:px-4 py-2 md:py-3 bg-[var(--secondary-color)] rounded-lg text-sm disabled:opacity-50 hover:bg-opacity-80 transition-all flex items-center justify-center gap-1 md:gap-2"
                  >
                    <div className="icon-sparkles text-base shrink-0"></div>
                    <span className="hidden sm:inline truncate">Enhance</span>
                    <span className="sm:hidden truncate">✨</span>
                  </button>
                  <button 
                    onClick={handleSend}
                    disabled={!input.trim() || isLoading}
                    className="shrink-0 px-4 md:px-6 py-2 md:py-3 bg-[var(--primary-color)] rounded-lg disabled:opacity-50 hover:bg-[var(--accent-color)] transition-all flex items-center justify-center"
                  >
                    <div className="icon-send text-lg md:text-xl"></div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ChatInterface error:', error);
    return null;
  }
}
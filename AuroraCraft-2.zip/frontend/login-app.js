class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="p-8 text-center">Error loading login</div>;
    }
    return this.props.children;
  }
}

function LoginApp() {
  try {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" data-name="login-app" data-file="login-app.js">
        <LoginForm />
      </div>
    );
  } catch (error) {
    console.error('LoginApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><LoginApp /></ErrorBoundary>);
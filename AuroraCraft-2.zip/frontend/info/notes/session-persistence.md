# Session Persistence

## Overview
Sessions now properly save and restore chat history. When you reopen a session from the history page, all previous messages are loaded.

## How It Works
1. **Session Creation**: When you send your first message, a new session is created with the message stored
2. **Message Storage**: After each AI response, the complete message history is saved to the session
3. **Session Loading**: When opening a session from history, the chat interface loads all previous messages from the database

## Data Structure
Each session stores:
- name: Session title (first 50 characters of initial message)
- model: AI model used
- messageCount: Total number of messages
- messages: Array of all chat messages [{role: 'user'/'ai', content: '...'}]

## URL Parameters
Sessions are identified by URL parameter: `ide.html?session={sessionId}`
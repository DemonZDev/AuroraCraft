# AuroraCraft - AI-Powered Minecraft Plugin Development

## Overview
AuroraCraft is a comprehensive web-based IDE for building Minecraft plugins using advanced AI language models (GPT-4, Claude 3, Gemini, DeepSeek, etc.). It provides an interactive development environment combining chat-based AI assistance, real-time code editing, and integrated compilation.

## Key Features

### Authentication System
- User registration and login system
- First user automatically becomes admin
- Protected routes for sessions and admin panel
- Public access to homepage and chat

### AI Chat Interface
- Clean, modern chat interface for plugin development
- Real-time AI responses
- Suggestion prompts for quick starts

### Development Environment
- Real-time code editor supporting Java, Kotlin, YAML, XML, and more
- File tree navigation with full CRUD operations
- Integrated Maven compilation with Java 21 support
- One-click JAR generation and download

### AI Integration
- Multi-model LLM support (OpenAI, Anthropic, Google, etc.)
- Prompt enhancement for clearer instructions
- Token usage tracking per model and session
- Session-based memory for context retention

### Project Structure
- `index.html` - Homepage with features and navigation
- `ide.html` - Main IDE interface with chat and code editor
- `sessions.html` - Session management and history
- `admin.html` - Administrative dashboard
- `components/` - React components for UI elements
- `utils/` - Utility functions including AI agent helpers

## Technical Stack
- **Frontend**: React 18, TailwindCSS
- **AI Integration**: Multi-provider LLM support via invokeAIAgent
- **Build System**: Maven with Java 21
- **Target Platform**: Bukkit/Spigot/Paper Minecraft servers

## Getting Started
1. Navigate to the IDE page
2. Select your preferred AI model
3. Choose a mode (Chat/Plan/Debug)
4. Start describing your plugin idea
5. The AI will guide you through planning, coding, and compilation

## Version
Initial release - November 2025
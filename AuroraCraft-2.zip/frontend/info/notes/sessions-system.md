# Sessions System

## Overview
Sessions represent individual chat conversations and plugin development projects for each user.

## Data Structure
Sessions are stored in Trickle database with objectType `session:{userId}` containing:
- name: Session/project name
- model: AI model used (GPT-4, Claude 3, etc.)
- messageCount: Number of messages in the session
- createdAt: Session creation timestamp

## Features
- User-specific sessions (each user only sees their own)
- Empty state for new users with no sessions
- Real-time session loading from database
- Session creation from chat interface

## Access Control
- Sessions page requires authentication
- Users can only view and manage their own sessions
- Sessions are isolated per user using objectType pattern
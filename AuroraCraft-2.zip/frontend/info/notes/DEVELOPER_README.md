# AuroraCraft - Developer Documentation

## Project Overview

**AuroraCraft** is an AI-powered Minecraft plugin development platform that enables users to create, plan, debug, and manage Minecraft server plugins through conversational AI interfaces. The platform supports multiple AI models, token-based usage management, and complete project lifecycle management.

**Version:** 1.0.0  
**Last Updated:** November 2025  
**License:** MIT (Assumed)

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Technology Stack](#technology-stack)
3. [Database Schema](#database-schema)
4. [Project Structure](#project-structure)
5. [Core Features](#core-features)
6. [AI Integration System](#ai-integration-system)
7. [Token Management System](#token-management-system)
8. [Authentication & Authorization](#authentication--authorization)
9. [File Management](#file-management)
10. [Configuration](#configuration)
11. [API Reference](#api-reference)
12. [Deployment](#deployment)
13. [Development Guidelines](#development-guidelines)

---

## Architecture Overview

AuroraCraft follows a **Multi-Page Application (MPA)** architecture with the following design principles:

- **Frontend-Only Architecture**: No backend server required, runs entirely in browser
- **Trickle Database**: Built-in database service for data persistence
- **Modular Component System**: React 18 components with functional paradigm
- **Multi-AI Provider Support**: Flexible AI model routing and management
- **Token-Based Usage Control**: Fine-grained resource management per user

### Key Architectural Components

```
┌─────────────────────────────────────────────────┐
│                   Frontend Layer                 │
│  (React 18 + TailwindCSS + Lucide Icons)       │
└─────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────┐
│              AI Router & Agent Layer             │
│  (Multi-model support, Prompt enhancement)      │
└─────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────┐
│             Token Management Layer               │
│  (Usage tracking, Context counting)             │
└─────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────┐
│              Trickle Database Layer              │
│  (User, Session, Model, Provider, Token data)   │
└─────────────────────────────────────────────────┘
```

---

## Technology Stack

### Frontend
- **React 18** (Production build via CDN)
- **TailwindCSS** (Utility-first styling)
- **Lucide Icons** (Icon library)
- **Babel Standalone** (JSX transpilation)

### Database
- **Trickle Database API** (Built-in object storage)

### AI Integration
- **Proxy API**: `https://proxy-api.trickle-app.host/` for CORS-free third-party API calls
- **Supported Providers**: OpenAI, Anthropic, Google, DeepSeek, Custom

### Build Tools
- **None Required**: Direct browser execution, no build step

---

## Database Schema

### Tables Overview

#### 1. **user**
Stores user account information and token balance.

| Field | Type | Description |
|-------|------|-------------|
| username | text | User's display name |
| email | text | User's email address |
| password | text | User's password (plain text - should be hashed in production) |
| role | text | User role: `admin` or `user` |
| tokens | number | Available token balance |
| totalTokensUsed | number | Total tokens consumed historically |
| avatar | text | Base64 encoded avatar image (optional) |

#### 2. **ai_provider**
Configuration for AI service providers.

| Field | Type | Description |
|-------|------|-------------|
| Name | text | Provider display name |
| BaseURL | text | API endpoint base URL |
| AuthType | text | Authentication type: `Bearer Token`, `API Key`, `Custom Header` |
| Headers | text | Custom headers in JSON format |
| DefaultPayload | text | Default request payload template (JSON) |
| HealthCheckEndpoint | text | Health check endpoint path |
| Status | text | Provider status: `active`, `inactive`, `testing` |
| APIKey | text | API authentication key |

#### 3. **ai_model**
Individual AI models available for use.

| Field | Type | Description |
|-------|------|-------------|
| ProviderId | text | Associated provider ID |
| ModelID | text | Model identifier for API calls |
| FriendlyName | text | Display name for UI |
| UsageCost | number | Cost per token (deprecated, use TokenAmount) |
| Status | text | Model availability: `enabled`, `disabled` |
| PromptFormat | text | Custom prompt format override |
| Parameters | text | Model-specific parameters (JSON) |
| Tags | array | Model tags: `Recommended`, `Experimental`, `Fast`, `Budget` |
| TokensPerContext | number | **Deprecated** - not used |
| TokenAmount | number | Tokens deducted per context interval (decimal supported: 1, 1.5, 2.5) |

#### 4. **session:${userId}**
User's plugin development sessions (scoped per user).

| Field | Type | Description |
|-------|------|-------------|
| name | text | Session/project name |
| model | text | AI model ID used |
| mode | text | Development mode: `agent`, `chat`, `plan`, `test` |
| software | text | Target software: `paper`, `spigot`, `bukkit`, `purpur` |
| creatorType | text | Project type: `minecraft-plugin`, `minecraft-mod`, `discord-bot` |
| messageCount | number | Total messages in conversation |
| messages | array | Chat history: `[{role: 'user'/'ai', content: '...'}]` |
| projectFiles | array | Uploaded project files with metadata |
| contextCount_${sessionId} | number | Context counter for token deduction tracking |

#### 5. **token_transaction**
Token usage and transaction history.

| Field | Type | Description |
|-------|------|-------------|
| userId | text | User who used tokens |
| sessionId | text | Session where tokens were used |
| modelId | text | AI model used |
| tokensUsed | number | Number of tokens consumed |
| promptLength | number | Length of user prompt |
| responseLength | number | Length of AI response |
| transactionType | text | Transaction type: `usage`, `purchase`, `admin_grant`, `refund` |

#### 6. **system_settings**
Global system configuration.

| Field | Type | Description |
|-------|------|-------------|
| TokensPerContextInterval | number | Tokens deducted every X contexts (default: 10) |

---

## Project Structure

```
auroracraft/
├── index.html                      # Homepage
├── ide.html                        # Main chat/IDE interface
├── sessions.html                   # Session management page
├── admin.html                      # Admin dashboard
├── admin-tokens.html              # Token management page
├── account.html                    # User account settings
├── register.html                   # User registration
├── login.html                      # User login
│
├── app.js                          # Homepage app logic
├── ide-app.js                      # IDE app logic
├── sessions-app.js                 # Sessions app logic
├── admin-app.js                    # Admin app logic
├── admin-tokens-app.js            # Token management logic
├── account-app.js                  # Account settings logic
├── register-app.js                 # Registration logic
├── login-app.js                    # Login logic
│
├── components/
│   ├── Header.js                   # Shared navigation header
│   ├── Hero.js                     # Homepage hero section
│   ├── FeatureCard.js             # Feature display card
│   ├── Footer.js                   # Shared footer
│   ├── Icon.js                     # Icon wrapper component
│   │
│   ├── auth/
│   │   ├── RegisterForm.js        # Registration form
│   │   └── LoginForm.js           # Login form
│   │
│   ├── chat/
│   │   └── ChatInterface.js       # Main chat interface
│   │
│   ├── sessions/
│   │   └── SessionCard.js         # Session card component
│   │
│   └── admin/
│       ├── StatsCard.js           # Statistics card
│       └── SettingsForm.js        # Settings configuration form
│
├── utils/
│   ├── aiAgent.js                 # Core AI agent logic
│   ├── aiRouter.js                # Multi-model routing
│   ├── tokenManager.js            # Token management system
│   ├── validation.js              # Form validation
│   ├── agentCore.js               # Agent core engine (advanced)
│   ├── phaseManager.js            # Project phase management
│   ├── fileManager.js             # File system management
│   ├── memorySystem.js            # Agent memory system
│   └── pluginBuilder.js           # Plugin code generation
│
└── trickle/
    ├── assets/                     # Project assets (images, etc.)
    ├── notes/
    │   ├── README.md              # Project overview
    │   ├── auth-system.md         # Auth documentation
    │   ├── sessions-system.md     # Sessions documentation
    │   └── session-persistence.md # Session persistence notes
    └── rules/
        ├── rule_for_readme_maintenance.md
        └── rule_for_auth_protection.md
```

---

## Core Features

### 1. **Multi-Mode AI Chat**
- **Agent Mode**: Autonomous plugin creation with minimal user interaction
- **Chat Mode**: Interactive conversation with step-by-step guidance
- **Plan Mode**: Generates detailed project architecture and roadmap
- **Test Mode**: Code review, bug detection, and optimization suggestions

### 2. **Session Management**
- Create unlimited development sessions
- Persistent chat history per session
- Project file upload and organization
- Session rename, delete, and bulk operations

### 3. **Token System**
- Context-based token deduction (configurable interval)
- Per-model token costs (decimal support: 1, 1.5, 2.5 tokens)
- Admin users have unlimited tokens
- Transaction history tracking
- Admin can grant tokens to users

### 4. **Multi-Model Support**
- Dynamic model switching during conversation
- Provider health check testing
- Model tags: Recommended, Experimental, Fast, Budget
- Custom parameters per model

### 5. **File Upload**
- Upload multiple files to session project
- Directory path specification support
- File tree organization
- Supports all text-based file formats

### 6. **User Roles**
- **Admin**: Full system access, unlimited tokens, user management
- **User**: Standard access, token-limited usage
- First registered user automatically becomes admin

---

## AI Integration System

### AI Router (`utils/aiRouter.js`)

The AI Router handles multi-model support and provider management.

**Key Functions:**

```javascript
// Get all active AI models
async function getActiveModels()

// Invoke specific model with system and user prompts
async function invokeModel(modelId, systemPrompt, userPrompt)
```

**Model Selection Flow:**
1. Retrieve active providers (Status: `active`)
2. Filter enabled models (Status: `enabled`)
3. Match model to provider
4. Build API request with proper authentication
5. Route through Trickle Proxy API to avoid CORS
6. Parse response and extract content

**Provider Authentication:**
- **Bearer Token**: `Authorization: Bearer ${apiKey}`
- **API Key**: `X-API-Key: ${apiKey}`
- **Custom Header**: Parse from provider's Headers field

### AI Agent (`utils/aiAgent.js`)

**Core Functions:**

```javascript
// Main plugin creation agent
async function createMinecraftPluginAgent(
  userRequest, 
  mode, 
  software, 
  chatHistory, 
  modelId
)

// Enhance user prompts for clarity
async function enhancePrompt(prompt)

// Generate project implementation plan
async function generatePluginPlan(description, software)

// Debug compilation errors
async function debugCompilationError(errorLog, software)

// Test and review plugin code
async function testPluginCode(codeFiles, software)
```

**Agent Prompt Template Structure:**
```
CRITICAL RULES:
- Complete, working code only
- Proper Java syntax and imports
- Follow ${software} API conventions
- Include error handling
- Use semantic versioning
- Extend JavaPlugin in main class
- Include plugin.yml with correct structure

MODE: ${mode}
[Mode-specific instructions]

REQUIRED FILES:
1. Main class
2. plugin.yml
3. pom.xml
4. Additional classes as needed

RESPONSE FORMAT:
1. Explanation
2. File structure
3. All code files
4. Setup instructions
5. Usage examples
```

---

## Token Management System

### Architecture

The token system uses a **context-based deduction model**:

1. **Context Counting**: Each user-AI message pair = 1 context
2. **Interval Deduction**: Tokens deducted every X contexts (configurable)
3. **Per-Model Costs**: Each model has a `TokenAmount` (can be decimal)
4. **Session Tracking**: Context count stored per session per user

### Token Manager (`utils/tokenManager.js`)

**Key Methods:**

```javascript
class TokenManager {
  // Get user's current token balance
  async getUserTokenBalance(userId)
  
  // Check if user is admin
  async isAdmin(userId)
  
  // Get token cost for specific model
  async getModelTokenCost(modelId)
  
  // Get system-wide context interval
  async getContextInterval()
  
  // Check if user can send message
  async canUserSendMessage(userId, modelId)
  
  // Deduct tokens based on context count
  async deductTokens(userId, sessionId, modelId, promptLength, responseLength)
  
  // Admin grants tokens to user
  async addTokens(userId, amount, transactionType)
  
  // Get user's transaction history
  async getTransactionHistory(userId, limit)
}
```

### Token Deduction Example

**Configuration:**
- `TokensPerContextInterval`: 10
- Model `TokenAmount`: 1.5

**Flow:**
1. User sends message → Context count++
2. If context count reaches 10 → Deduct 1.5 tokens
3. Reset context count to 0
4. Create transaction record
5. Update user's token balance

**Admin Exception:**
- Admins bypass all token checks
- No context counting for admins
- No transaction records for admins

---

## Authentication & Authorization

### User Registration

**First User Rule**: First registered user automatically becomes `admin`

**Registration Flow:**
1. Validate form fields (username, email, password)
2. Check if any users exist
3. If no users exist → Set role to `admin`
4. Otherwise → Set role to `user`
5. Create user object with 100 initial tokens
6. Store in Trickle database

### Login

**Authentication Method**: Email + Password (plain text comparison)

**Login Flow:**
1. Validate email format and password length
2. Query all users from database
3. Find matching email and password
4. Store user object in localStorage as `currentUser`
5. Redirect to IDE page

### Route Protection

**Protected Routes:**
- `sessions.html` → Requires authentication
- `account.html` → Requires authentication
- `admin.html` → Requires admin role
- `admin-tokens.html` → Requires admin role

**Public Routes:**
- `index.html` → Homepage
- `ide.html` → Chat interface
- `register.html` → Registration
- `login.html` → Login

**Protection Implementation:**
```javascript
React.useEffect(() => {
  const user = localStorage.getItem('currentUser');
  if (!user) {
    window.location.href = 'login.html';
    return;
  }
  const userData = JSON.parse(user);
  // For admin-only pages:
  if (userData.objectData?.role !== 'admin') {
    window.location.href = 'index.html';
    return;
  }
}, []);
```

---

## File Management

### Session File Upload

**Features:**
- Multiple file upload support
- Directory path specification
- File tree organization
- Supports all text-based formats

**Upload Flow:**
1. User selects files via file input
2. Upload modal displays selected files
3. User specifies path (optional):
   - Blank or `/` → Root directory
   - `/src/` → src directory
   - `config/` → config directory
4. Files read via FileReader API
5. File content stored in session's `projectFiles` array
6. Each file object contains:
   - `name`: Filename
   - `path`: Full path in project
   - `content`: File content as text
   - `uploadedAt`: ISO timestamp

**Data Structure:**
```javascript
{
  projectFiles: [
    {
      name: "Main.java",
      path: "src/Main.java",
      content: "package com.example...",
      uploadedAt: "2025-11-17T05:44:20Z"
    }
  ]
}
```

---

## Configuration

### System Settings

**Configurable via Admin Panel:**

1. **TokensPerContextInterval** (Database)
   - Default: 10
   - Controls how often tokens are deducted
   - Stored in `system_settings` table

2. **Site Settings** (LocalStorage)
   - `siteName`: Platform name (default: "AuroraCraft")
   - `aiName`: AI assistant name (default: "AuroraCraft")
   - `maxSessions`: Max sessions per user (default: "10")
   - `siteLogo`: Site logo image (Base64)
   - `aiAvatar`: AI avatar image (Base64)

### AI Provider Configuration

**Required Fields:**
- `Name`: Provider display name
- `BaseURL`: Complete API endpoint URL
- `AuthType`: Authentication method
- `APIKey`: Authentication credential
- `Status`: Must be `active` for use

**Example OpenAI Configuration:**
```json
{
  "Name": "OpenAI",
  "BaseURL": "https://api.openai.com/v1/chat/completions",
  "AuthType": "Bearer Token",
  "Headers": "{}",
  "DefaultPayload": "{\"temperature\": 0.7}",
  "Status": "active",
  "APIKey": "sk-..."
}
```

### AI Model Configuration

**Required Fields:**
- `ProviderId`: Link to provider
- `ModelID`: API model identifier (e.g., "gpt-4")
- `FriendlyName`: Display name (e.g., "GPT-4")
- `TokenAmount`: Tokens per context interval (decimal allowed)
- `Status`: Must be `enabled` for use

**Example:**
```json
{
  "ProviderId": "provider-xyz-123",
  "ModelID": "gpt-4",
  "FriendlyName": "GPT-4",
  "TokenAmount": 2.5,
  "Status": "enabled",
  "Tags": ["Recommended", "Fast"]
}
```

---

## API Reference

### Trickle Database API

All database operations use the Trickle Object API:

```javascript
// Create object
await trickleCreateObject(objectType, objectData)

// Update object
await trickleUpdateObject(objectType, objectId, objectData)

// Get single object
await trickleGetObject(objectType, objectId)

// List objects
await trickleListObjects(objectType, limit, descending, nextPageToken)

// Delete object
await trickleDeleteObject(objectType, objectId)
```

**ObjectType Patterns:**
- Simple: `user`, `ai_provider`, `ai_model`
- Scoped: `session:${userId}` for user-specific sessions

### Trickle Proxy API

**Endpoint:**
```
https://proxy-api.trickle-app.host/?url=${encodeURIComponent(targetUrl)}
```

**Usage:**
```javascript
const response = await fetch(proxyUrl, {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${apiKey}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(payload)
});
```

---

## Deployment

### Requirements
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Internet connection for CDN resources
- Trickle platform account (for database access)

### Deployment Steps

1. **Upload Files**: Upload all project files to Trickle hosting
2. **Configure Domain**: Set custom domain in Trickle settings
3. **Initialize Database**: Create initial admin user
4. **Configure Providers**: Add AI providers in admin panel
5. **Add Models**: Configure AI models with token costs
6. **Set System Settings**: Configure token interval

### Initial Setup Checklist

- [ ] Deploy all HTML, JS, and component files
- [ ] Register first admin user
- [ ] Add at least one AI provider
- [ ] Configure at least one AI model
- [ ] Set `TokensPerContextInterval` in system settings
- [ ] Test file upload functionality
- [ ] Verify token deduction system

---

## Development Guidelines

### Code Style

1. **React Components**: Functional components with hooks only
2. **Error Handling**: All components wrapped in ErrorBoundary
3. **Naming Conventions**:
   - Components: PascalCase (e.g., `ChatInterface`)
   - Files: camelCase (e.g., `aiRouter.js`)
   - Functions: camelCase (e.g., `getUserTokenBalance`)

### Component Structure

```javascript
function ComponentName() {
  try {
    // State declarations
    const [state, setState] = React.useState(null);
    
    // Effects
    React.useEffect(() => {}, []);
    
    // Event handlers
    const handleEvent = () => {};
    
    // Render
    return (
      <div data-name="component-name" data-file="path/to/file.js">
        {/* Component content */}
      </div>
    );
  } catch (error) {
    console.error('Component error:', error);
    return null;
  }
}
```

### Adding New AI Providers

1. **Admin Panel** → Providers → Add Provider
2. Fill in provider details:
   - Name, BaseURL, AuthType, APIKey
   - Headers (JSON), DefaultPayload (JSON)
   - Status: Set to `active`
3. Test provider connection
4. Add models linked to provider

### Adding New Features

1. Create new HTML page (if needed)
2. Create corresponding app.js file
3. Create required components in `components/`
4. Add utility functions in `utils/`
5. Update Header component navigation
6. Update README.md documentation
7. Test authentication requirements

### Security Considerations

**Current Implementation:**
- ⚠️ **Passwords stored in plain text** - Implement hashing (bcrypt) in production
- ⚠️ **No HTTPS enforcement** - Use HTTPS in production
- ✅ **API keys not exposed** - Stored server-side via Trickle DB
- ✅ **CORS handled** - Via Trickle Proxy API

**Production Recommendations:**
1. Implement password hashing (bcrypt, argon2)
2. Add rate limiting for API calls
3. Implement session tokens (JWT)
4. Add CSRF protection
5. Sanitize user inputs
6. Implement proper error logging

---

## Common Issues & Solutions

### Issue: "Model not found"
**Solution**: Ensure model Status is `enabled` and provider Status is `active`

### Issue: "Authentication failed"
**Solution**: Verify API key is correct and AuthType matches provider requirements

### Issue: "API returned HTML instead of JSON"
**Solution**: Check provider BaseURL is complete endpoint, not just domain

### Issue: "Insufficient tokens"
**Solution**: Admin can grant tokens via Admin → Token Management

### Issue: "File upload not working"
**Solution**: Ensure files are text-based and session exists in database

---

## Future Enhancements

### Planned Features
- Minecraft Mod creation support
- Discord Bot creation support
- Real-time code compilation
- Plugin marketplace
- Team collaboration
- Version control integration
- Advanced code analysis
- Automated testing

### Technical Improvements
- Password encryption
- Session management with JWT
- WebSocket support for real-time updates
- Code syntax highlighting
- File tree with drag-and-drop
- Advanced search and filtering
- Export/import projects
- Backup and restore functionality

---

## Contributing

When modifying AuroraCraft:

1. Follow existing code structure and patterns
2. Test all authentication flows
3. Verify token deduction works correctly
4. Update README.md for significant changes
5. Test with multiple AI providers
6. Ensure mobile responsiveness
7. Add comments for complex logic
8. Use ErrorBoundary for new components

---

## License

MIT License (Assumed - Please specify actual license)

---

## Support

For issues or questions:
- Email: support@trickle.so
- Documentation: This file

---

**Last Updated**: November 17, 2025  
**Maintained By**: AuroraCraft Development Team
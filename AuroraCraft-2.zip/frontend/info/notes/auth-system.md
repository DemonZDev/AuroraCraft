# Authentication System

## Overview
AuroraCraft includes a complete user authentication system with registration and login functionality.

## Features
- User registration with username, email, and password
- Password confirmation validation
- Email format validation
- Login with email and password
- Session management using localStorage
- Logout functionality

## Pages
- `register.html` - User registration page
- `login.html` - User login page

## Components
- `RegisterForm` - Registration form with validation
- `LoginForm` - Login form with authentication

## Validation Rules
- Username: minimum 3 characters
- Email: valid email format required
- Password: minimum 6 characters
- Confirm Password: must match password

## Data Storage
User data is stored in Trickle database with objectType 'user' containing:
- username
- email
- password

## Session Management
- Logged-in user data stored in localStorage as 'currentUser'
- Header shows logout button when user is authenticated
- Logout clears localStorage and refreshes page
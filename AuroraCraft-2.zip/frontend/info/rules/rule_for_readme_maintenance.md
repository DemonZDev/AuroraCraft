When project updates occur

- Check if README.md in trickle/notes needs updating
- Update README.md when:
  - New features are added
  - Project structure changes significantly
  - Key components are modified or added
  - Technical dependencies change
  - Usage instructions need clarification
- Keep README concise and focused on essential information
- Maintain consistency with actual implementation
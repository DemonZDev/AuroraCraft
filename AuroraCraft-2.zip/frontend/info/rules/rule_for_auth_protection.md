When working with pages and authentication

- Homepage (index.html) and Chat (ide.html) are public and accessible to everyone
- All other pages (sessions, admin) require authentication
- Add authentication check at the start of each protected page component using React.useEffect
- Redirect to login.html if user is not authenticated
- Admin panel requires both authentication AND admin role check
- First registered user automatically gets admin role
- Check user role with: JSON.parse(localStorage.getItem('currentUser')).objectData?.role === 'admin'
- Admin navigation links only show for users with admin role
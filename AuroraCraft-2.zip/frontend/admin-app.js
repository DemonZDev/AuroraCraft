class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="p-8 text-center">Error loading admin panel</div>;
    }
    return this.props.children;
  }
}

function AdminApp() {
  try {
    const [activeTab, setActiveTab] = React.useState('overview');
    const [users, setUsers] = React.useState([]);
    const [providers, setProviders] = React.useState([]);
    const [models, setModels] = React.useState([]);
    const [allSessions, setAllSessions] = React.useState([]);
    const [filteredSessions, setFilteredSessions] = React.useState([]);
    const [searchUsername, setSearchUsername] = React.useState('');
    const [selectedProjects, setSelectedProjects] = React.useState([]);
    const [showAdminDeleteModal, setShowAdminDeleteModal] = React.useState(false);
    const [projectToDelete, setProjectToDelete] = React.useState(null);
    const [showAdminRenameModal, setShowAdminRenameModal] = React.useState(false);
    const [projectToRename, setProjectToRename] = React.useState(null);
    const [newProjectName, setNewProjectName] = React.useState('');
    const [showProviderForm, setShowProviderForm] = React.useState(false);
    const [showModelForm, setShowModelForm] = React.useState(false);
    const [showUserForm, setShowUserForm] = React.useState(false);
    const [showEditRoleModal, setShowEditRoleModal] = React.useState(false);
    const [showEditTokenModal, setShowEditTokenModal] = React.useState(false);
    const [selectedUserForEdit, setSelectedUserForEdit] = React.useState(null);
    const [selectedUserForTokenEdit, setSelectedUserForTokenEdit] = React.useState(null);
    const [tokenEditAmount, setTokenEditAmount] = React.useState('');
    const [testingProvider, setTestingProvider] = React.useState(null);
    const [userForm, setUserForm] = React.useState({
      username: '', email: '', password: '', confirmPassword: '', role: 'user', tokens: 100
    });
    const [providerForm, setProviderForm] = React.useState({
      Name: '', BaseURL: '', AuthType: 'Bearer Token', Headers: '{}',
      DefaultPayload: '{}', HealthCheckEndpoint: '', Status: 'inactive', APIKey: ''
    });
    const [modelForm, setModelForm] = React.useState({
      ProviderId: '', ModelID: '', FriendlyName: '',
      Status: 'enabled', PromptFormat: '', Parameters: '{}', Tags: [], TokenAmount: '1'
    });
    const [customTag, setCustomTag] = React.useState('');
    const [stats, setStats] = React.useState([
      { icon: 'users', label: 'Total Users', value: '0', color: 'bg-blue-500' },
      { icon: 'folder', label: 'Active Sessions', value: '0', color: 'bg-green-500' },
      { icon: 'zap', label: 'AI Providers', value: '4', color: 'bg-purple-500' },
      { icon: 'trending-up', label: 'System Status', value: 'Active', color: 'bg-orange-500' }
    ]);
    const [systemSettings, setSystemSettings] = React.useState({ TokensPerContextInterval: 10 });

    React.useEffect(() => {
      const user = localStorage.getItem('currentUser');
      if (!user) {
        window.location.href = 'login.html';
        return;
      }
      const userData = JSON.parse(user);
      // Check both possible structures for role
      const userRole = userData.role || userData.objectData?.role;
      if (userRole !== 'admin') {
        window.location.href = 'index.html';
        return;
      }
      loadData();
    }, []);

    React.useEffect(() => {
      if (searchUsername.trim() === '') {
        setFilteredSessions(allSessions);
      } else {
        setFilteredSessions(
          allSessions.filter(session => 
            session.userName.toLowerCase().includes(searchUsername.toLowerCase())
          )
        );
      }
    }, [searchUsername, allSessions]);

    const loadData = async () => {
      try {
        const [usersData, providersData, modelsData, settingsData] = await Promise.all([
          trickleListObjects('user', 1000, true),
          trickleListObjects('ai_provider', 1000, true),
          trickleListObjects('ai_model', 1000, true),
          trickleListObjects('system_settings', 1, true)
        ]);
        setUsers(usersData.items);
        setProviders(providersData.items);
        setModels(modelsData.items);
        if (settingsData.items.length > 0) {
          setSystemSettings(settingsData.items[0].objectData);
        }
        setStats(prev => prev.map(stat => {
          if (stat.label === 'Total Users') return { ...stat, value: usersData.items.length.toString() };
          if (stat.label === 'AI Providers') return { ...stat, value: providersData.items.length.toString() };
          return stat;
        }));
        
        await loadAllSessions(usersData.items);
      } catch (error) {
        console.error('Failed to load data:', error);
      }
    };

    const loadAllSessions = async (usersList) => {
      try {
        const sessions = [];
        for (const user of usersList) {
          const userSessions = await trickleListObjects(`session:${user.objectId}`, 1000, true);
          userSessions.items.forEach(session => {
            sessions.push({
              ...session,
              userName: user.objectData.username,
              userEmail: user.objectData.email,
              userId: user.objectId
            });
          });
        }
        setAllSessions(sessions);
        setFilteredSessions(sessions);
      } catch (error) {
        console.error('Failed to load sessions:', error);
      }
    };

    const createUser = async () => {
      if (!userForm.username || !userForm.email || !userForm.password) {
        alert('Please fill in all required fields');
        return;
      }
      if (userForm.password !== userForm.confirmPassword) {
        alert('Passwords do not match');
        return;
      }
      if (userForm.password.length < 6) {
        alert('Password must be at least 6 characters');
        return;
      }
      try {
        await trickleCreateObject('user', {
          username: userForm.username,
          email: userForm.email,
          password: userForm.password,
          role: userForm.role,
          tokens: parseInt(userForm.tokens) || 100,
          totalTokensUsed: 0
        });
        setShowUserForm(false);
        setUserForm({ username: '', email: '', password: '', confirmPassword: '', role: 'user', tokens: 100 });
        loadData();
        alert('User created successfully');
      } catch (error) {
        console.error('Failed to create user:', error);
        alert('Failed to create user');
      }
    };

    const updateUserRole = async () => {
      if (!selectedUserForEdit) return;
      try {
        await trickleUpdateObject('user', selectedUserForEdit.objectId, {
          ...selectedUserForEdit.objectData,
          role: selectedUserForEdit.objectData.role
        });
        setShowEditRoleModal(false);
        setSelectedUserForEdit(null);
        loadData();
        alert('User role updated successfully');
      } catch (error) {
        console.error('Failed to update user role:', error);
        alert('Failed to update user role');
      }
    };

    const updateUserTokens = async () => {
      if (!selectedUserForTokenEdit) return;
      const newTokens = parseInt(tokenEditAmount);
      if (isNaN(newTokens) || newTokens < 0) {
        alert('Please enter a valid token amount (0 or greater)');
        return;
      }
      try {
        await trickleUpdateObject('user', selectedUserForTokenEdit.objectId, {
          ...selectedUserForTokenEdit.objectData,
          tokens: newTokens
        });
        setShowEditTokenModal(false);
        setSelectedUserForTokenEdit(null);
        setTokenEditAmount('');
        loadData();
        alert('User tokens updated successfully');
      } catch (error) {
        console.error('Failed to update tokens:', error);
        alert('Failed to update tokens');
      }
    };

    const deleteUser = async (userId) => {
      if (!confirm('Are you sure you want to delete this user?')) return;
      try {
        await trickleDeleteObject('user', userId);
        loadData();
      } catch (error) {
        console.error('Failed to delete user:', error);
      }
    };

    const saveProvider = async () => {
      try {
        if (providerForm.objectId) {
          await trickleUpdateObject('ai_provider', providerForm.objectId, providerForm);
        } else {
          await trickleCreateObject('ai_provider', providerForm);
        }
        setShowProviderForm(false);
        setProviderForm({
          Name: '', BaseURL: '', AuthType: 'Bearer Token', Headers: '{}',
          DefaultPayload: '{}', HealthCheckEndpoint: '', Status: 'inactive', APIKey: ''
        });
        loadData();
      } catch (error) {
        console.error('Failed to save provider:', error);
        alert('Failed to save provider');
      }
    };

    const deleteProvider = async (id) => {
      if (!confirm('Delete this provider? Associated models will remain.')) return;
      try {
        await trickleDeleteObject('ai_provider', id);
        loadData();
      } catch (error) {
        console.error('Failed to delete provider:', error);
      }
    };

    const testProvider = async (provider) => {
      setTestingProvider(provider.objectId);
      try {
        const headers = JSON.parse(provider.objectData.Headers || '{}');
        if (provider.objectData.AuthType === 'Bearer Token') {
          headers['Authorization'] = `Bearer ${provider.objectData.APIKey}`;
        } else if (provider.objectData.AuthType === 'API Key') {
          headers['X-API-Key'] = provider.objectData.APIKey;
        }
        const url = `https://proxy-api.trickle-app.host/?url=${encodeURIComponent(provider.objectData.BaseURL + (provider.objectData.HealthCheckEndpoint || ''))}`;
        const response = await fetch(url, { method: 'GET', headers });
        if (response.ok) {
          alert('Provider test successful!');
        } else {
          alert(`Provider test failed: ${response.status}`);
        }
      } catch (error) {
        alert(`Provider test failed: ${error.message}`);
      } finally {
        setTestingProvider(null);
      }
    };

    const saveModel = async () => {
      try {
        const modelData = {
          ...modelForm,
          TokenAmount: parseFloat(modelForm.TokenAmount) || 1
        };
        if (modelForm.objectId) {
          await trickleUpdateObject('ai_model', modelForm.objectId, modelData);
        } else {
          await trickleCreateObject('ai_model', modelData);
        }
        setShowModelForm(false);
        setModelForm({
          ProviderId: '', ModelID: '', FriendlyName: '',
          Status: 'enabled', PromptFormat: '', Parameters: '{}', Tags: [], TokenAmount: '1'
        });
        loadData();
      } catch (error) {
        console.error('Failed to save model:', error);
        alert('Failed to save model');
      }
    };

    const deleteModel = async (id) => {
      if (!confirm('Delete this model?')) return;
      try {
        await trickleDeleteObject('ai_model', id);
        loadData();
      } catch (error) {
        console.error('Failed to delete model:', error);
      }
    };

    const toggleProjectSelection = (projectId) => {
      setSelectedProjects(prev => 
        prev.includes(projectId) 
          ? prev.filter(id => id !== projectId)
          : [...prev, projectId]
      );
    };

    const deleteProject = async (project) => {
      try {
        await trickleDeleteObject(`session:${project.userId}`, project.objectId);
        loadData();
        setShowAdminDeleteModal(false);
        setProjectToDelete(null);
      } catch (error) {
        console.error('Failed to delete project:', error);
        alert('Failed to delete project');
      }
    };

    const deleteSelectedProjects = async () => {
      try {
        for (const projectId of selectedProjects) {
          const project = allSessions.find(s => s.objectId === projectId);
          if (project) {
            await trickleDeleteObject(`session:${project.userId}`, project.objectId);
          }
        }
        setSelectedProjects([]);
        loadData();
        setShowAdminDeleteModal(false);
      } catch (error) {
        console.error('Failed to delete projects:', error);
        alert('Failed to delete selected projects');
      }
    };

    const renameProject = async () => {
      if (!newProjectName.trim()) {
        alert('Please enter a project name');
        return;
      }
      try {
        await trickleUpdateObject(`session:${projectToRename.userId}`, projectToRename.objectId, {
          ...projectToRename.objectData,
          name: newProjectName
        });
        loadData();
        setShowAdminRenameModal(false);
        setProjectToRename(null);
        setNewProjectName('');
      } catch (error) {
        console.error('Failed to rename project:', error);
        alert('Failed to rename project');
      }
    };

    const user = localStorage.getItem('currentUser');
    if (!user) return null;
    const userData = JSON.parse(user);
    // Check both possible structures for role
    const userRole = userData.role || userData.objectData?.role;
    if (userRole !== 'admin') return null;

    return (
      <div className="min-h-screen" data-name="admin-app" data-file="admin-app.js">
        <Header />
        
        <div className="max-w-7xl mx-auto px-4 py-12">
          <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>

          <div className="flex gap-4 mb-8 border-b border-[var(--border-color)] overflow-x-auto">
            {['overview', 'users', 'projects', 'tokens', 'providers', 'models', 'settings'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 capitalize whitespace-nowrap ${activeTab === tab ? 'border-b-2 border-[var(--primary-color)] text-[var(--text-primary)]' : 'text-[var(--text-secondary)]'}`}
              >
                {tab}
              </button>
            ))}
          </div>

          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, i) => <StatsCard key={i} {...stat} />)}
            </div>
          )}

          {activeTab === 'projects' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">All User Projects</h2>
                <div className="flex items-center gap-4">
                  {selectedProjects.length > 0 && (
                    <button 
                      onClick={() => setShowAdminDeleteModal(true)} 
                      className="px-4 py-2 bg-red-500 bg-opacity-20 text-red-400 rounded-lg hover:bg-opacity-30"
                    >
                      Delete Selected ({selectedProjects.length})
                    </button>
                  )}
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search by username..."
                      value={searchUsername}
                      onChange={(e) => setSearchUsername(e.target.value)}
                      className="px-4 py-2 pl-10 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg w-64"
                    />
                    <div className="icon-search text-base absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--text-secondary)]"></div>
                  </div>
                  <div className="text-sm text-[var(--text-secondary)]">
                    {filteredSessions.length} project{filteredSessions.length !== 1 ? 's' : ''}
                  </div>
                </div>
              </div>

              {filteredSessions.length === 0 ? (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mx-auto mb-4">
                    <div className="icon-folder text-2xl text-[var(--primary-color)]"></div>
                  </div>
                  <h3 className="text-xl font-bold mb-2">No Projects Found</h3>
                  <p className="text-[var(--text-secondary)]">
                    {searchUsername ? 'No projects match your search criteria' : 'No projects have been created yet'}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredSessions.map(session => {
                    const totalMessages = session.objectData.messageCount || 0;
                    const contextCount = parseInt(session.objectData[`contextCount_${session.objectId}`] || 0);
                    
                    return (
                      <div key={session.objectId} className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6 relative">
                        <input
                          type="checkbox"
                          checked={selectedProjects.includes(session.objectId)}
                          onChange={() => toggleProjectSelection(session.objectId)}
                          className="absolute top-6 left-6 w-5 h-5 z-10"
                        />
                        <div className="flex items-start justify-between mb-4 ml-8">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-lg font-bold">{session.objectData.name || 'Untitled Project'}</h3>
                              <span className="text-xs px-2 py-1 bg-[var(--primary-color)] bg-opacity-20 text-[var(--primary-color)] rounded">
                                {session.objectData.model || 'Unknown Model'}
                              </span>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-[var(--text-secondary)]">
                              <div className="flex items-center gap-1">
                                <div className="icon-user text-base"></div>
                                <span>{session.userName}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <div className="icon-mail text-base"></div>
                                <span>{session.userEmail}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <div className="icon-calendar text-base"></div>
                                <span>{new Date(session.createdAt).toLocaleDateString()}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                window.location.href = `ide.html?session=${session.objectId}&userId=${session.userId}`;
                              }}
                              className="px-4 py-2 bg-[var(--primary-color)] rounded-lg hover:bg-[var(--accent-color)] transition-all"
                            >
                              View Project
                            </button>
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                setProjectToRename(session);
                                setNewProjectName(session.objectData.name || '');
                                setShowAdminRenameModal(true);
                              }}
                              className="px-4 py-2 bg-blue-500 bg-opacity-20 text-blue-400 rounded-lg hover:bg-opacity-30"
                            >
                              <div className="icon-edit text-base"></div>
                            </button>
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                setProjectToDelete(session);
                                setShowAdminDeleteModal(true);
                              }}
                              className="px-4 py-2 bg-red-500 bg-opacity-20 text-red-400 rounded-lg hover:bg-opacity-30"
                            >
                              <div className="icon-trash text-base"></div>
                            </button>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-[var(--border-color)]">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-blue-500 bg-opacity-10 rounded-lg flex items-center justify-center">
                              <div className="icon-message-circle text-sm text-blue-400"></div>
                            </div>
                            <div>
                              <div className="text-lg font-bold">{totalMessages}</div>
                              <div className="text-xs text-[var(--text-secondary)]">Messages</div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-purple-500 bg-opacity-10 rounded-lg flex items-center justify-center">
                              <div className="icon-activity text-sm text-purple-400"></div>
                            </div>
                            <div>
                              <div className="text-lg font-bold">{contextCount}</div>
                              <div className="text-xs text-[var(--text-secondary)]">Context Count</div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-green-500 bg-opacity-10 rounded-lg flex items-center justify-center">
                              <div className="icon-cpu text-sm text-green-400"></div>
                            </div>
                            <div>
                              <div className="text-lg font-bold">{session.objectData.mode || 'agent'}</div>
                              <div className="text-xs text-[var(--text-secondary)]">Mode</div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-orange-500 bg-opacity-10 rounded-lg flex items-center justify-center">
                              <div className="icon-package text-sm text-orange-400"></div>
                            </div>
                            <div>
                              <div className="text-lg font-bold">{session.objectData.software || 'paper'}</div>
                              <div className="text-xs text-[var(--text-secondary)]">Software</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {activeTab === 'tokens' && (
            <div className="space-y-6">
              <div className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6">
                <h3 className="text-xl font-bold mb-4">Global Token Settings</h3>
                <div className="max-w-md">
                  <label className="block text-sm font-medium mb-2">Token Deduction Per ___ Contexts</label>
                  <input 
                    type="number" 
                    min="1" 
                    step="1"
                    value={systemSettings.TokensPerContextInterval || 10}
                    onChange={async (e) => {
                      const value = parseInt(e.target.value) || 10;
                      try {
                        const settingsData = await trickleListObjects('system_settings', 1, true);
                        if (settingsData.items.length > 0) {
                          await trickleUpdateObject('system_settings', settingsData.items[0].objectId, { TokensPerContextInterval: value });
                        } else {
                          await trickleCreateObject('system_settings', { TokensPerContextInterval: value });
                        }
                        setSystemSettings({ TokensPerContextInterval: value });
                        alert('Context interval updated successfully');
                      } catch (error) {
                        alert('Failed to update settings');
                      }
                    }}
                    className="w-full px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg"
                  />
                  <p className="text-xs text-[var(--text-secondary)] mt-2">Example: If set to 10, tokens will be deducted every 10 contexts</p>
                </div>
              </div>

              <div className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold">Token Usage Overview</h3>
                  <button onClick={() => window.location.href = 'admin-tokens.html'} className="px-4 py-2 bg-[var(--primary-color)] rounded-lg">
                    Manage User Tokens
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-[var(--bg-darker)] rounded-lg border border-[var(--border-color)]">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 bg-yellow-500 bg-opacity-10 rounded-lg flex items-center justify-center">
                        <div className="icon-coins text-xl text-yellow-400"></div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold">Per {systemSettings.TokensPerContextInterval || 10}</div>
                        <div className="text-sm text-[var(--text-secondary)]">Contexts Interval</div>
                      </div>
                    </div>
                    <p className="text-xs text-[var(--text-secondary)]">Tokens are deducted every {systemSettings.TokensPerContextInterval || 10} contexts</p>
                  </div>
                  <div className="p-4 bg-[var(--bg-darker)] rounded-lg border border-[var(--border-color)]">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 bg-blue-500 bg-opacity-10 rounded-lg flex items-center justify-center">
                        <div className="icon-users text-xl text-blue-400"></div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold">{users.filter(u => u.objectData.role !== 'admin').length}</div>
                        <div className="text-sm text-[var(--text-secondary)]">Regular Users</div>
                      </div>
                    </div>
                    <p className="text-xs text-[var(--text-secondary)]">Admins have unlimited tokens</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'users' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">User Management</h2>
                <button onClick={() => setShowUserForm(true)} className="px-4 py-2 bg-[var(--primary-color)] rounded-lg">
                  <div className="icon-user-plus text-base inline-block mr-2"></div>Create User
                </button>
              </div>

              {showUserForm && (
                <div className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6">
                  <h3 className="font-bold mb-4">Create New User</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input placeholder="Username" value={userForm.username} onChange={(e) => setUserForm({...userForm, username: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <input type="email" placeholder="Email" value={userForm.email} onChange={(e) => setUserForm({...userForm, email: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <input type="password" placeholder="Password" value={userForm.password} onChange={(e) => setUserForm({...userForm, password: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <input type="password" placeholder="Confirm Password" value={userForm.confirmPassword} onChange={(e) => setUserForm({...userForm, confirmPassword: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <select value={userForm.role} onChange={(e) => setUserForm({...userForm, role: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg">
                      <option value="user">User</option>
                      <option value="admin">Admin</option>
                    </select>
                    <input type="number" placeholder="Initial Tokens" value={userForm.tokens} onChange={(e) => setUserForm({...userForm, tokens: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                  </div>
                  <div className="flex gap-2 mt-4">
                    <button onClick={createUser} className="px-4 py-2 bg-[var(--primary-color)] rounded-lg">Create User</button>
                    <button onClick={() => {setShowUserForm(false); setUserForm({ username: '', email: '', password: '', confirmPassword: '', role: 'user', tokens: 100 });}} className="px-4 py-2 bg-[var(--secondary-color)] rounded-lg">Cancel</button>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {users.map(user => (
                  <div key={user.objectId} className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center">
                          <div className="icon-user text-xl text-white"></div>
                        </div>
                        <div>
                          <h3 className="font-bold">{user.objectData.username}</h3>
                          <p className="text-sm text-[var(--text-secondary)]">{user.objectData.email}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className={`text-xs px-2 py-1 rounded ${user.objectData.role === 'admin' ? 'bg-purple-500 bg-opacity-20 text-purple-400' : 'bg-blue-500 bg-opacity-20 text-blue-400'}`}>
                              {user.objectData.role || 'user'}
                            </span>
                            <span className="text-xs text-[var(--text-secondary)]">
                              {user.objectData.tokens || 0} tokens
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => {setSelectedUserForEdit(user); setShowEditRoleModal(true);}}
                          className="px-4 py-2 bg-[var(--secondary-color)] rounded-lg hover:bg-opacity-80"
                        >
                          Edit Role
                        </button>
                        <button
                          onClick={() => {setSelectedUserForTokenEdit(user); setTokenEditAmount(user.objectData.tokens?.toString() || '0'); setShowEditTokenModal(true);}}
                          className="px-4 py-2 bg-yellow-500 bg-opacity-20 text-yellow-400 rounded-lg hover:bg-opacity-30"
                        >
                          Edit Tokens
                        </button>
                        <button
                          onClick={() => deleteUser(user.objectId)}
                          className="px-4 py-2 bg-red-500 bg-opacity-20 text-red-400 rounded-lg hover:bg-opacity-30"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'providers' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">AI Providers</h2>
                <button onClick={() => {setShowProviderForm(true); setProviderForm({Name: '', BaseURL: '', AuthType: 'Bearer Token', Headers: '{}', DefaultPayload: '{}', HealthCheckEndpoint: '', Status: 'inactive', APIKey: ''});}} className="px-4 py-2 bg-[var(--primary-color)] rounded-lg">
                  <div className="icon-plus text-base inline-block mr-2"></div>Add Provider
                </button>
              </div>

              {showProviderForm && (
                <div className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6">
                  <h3 className="font-bold mb-4">{providerForm.objectId ? 'Edit' : 'New'} Provider</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input placeholder="Name" value={providerForm.Name} onChange={(e) => setProviderForm({...providerForm, Name: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <input placeholder="Base URL" value={providerForm.BaseURL} onChange={(e) => setProviderForm({...providerForm, BaseURL: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <select value={providerForm.AuthType} onChange={(e) => setProviderForm({...providerForm, AuthType: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg">
                      <option>Bearer Token</option><option>API Key</option><option>Custom Header</option>
                    </select>
                    <input type="password" placeholder="API Key" value={providerForm.APIKey} onChange={(e) => setProviderForm({...providerForm, APIKey: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <input placeholder="Headers (JSON)" value={providerForm.Headers} onChange={(e) => setProviderForm({...providerForm, Headers: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <input placeholder="Health Check Endpoint" value={providerForm.HealthCheckEndpoint} onChange={(e) => setProviderForm({...providerForm, HealthCheckEndpoint: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <textarea placeholder="Default Payload (JSON)" value={providerForm.DefaultPayload} onChange={(e) => setProviderForm({...providerForm, DefaultPayload: e.target.value})} className="md:col-span-2 px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" rows="3"></textarea>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <button onClick={saveProvider} className="px-4 py-2 bg-[var(--primary-color)] rounded-lg">Save</button>
                    <button onClick={() => setShowProviderForm(false)} className="px-4 py-2 bg-[var(--secondary-color)] rounded-lg">Cancel</button>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {providers.map(provider => (
                  <div key={provider.objectId} className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="font-bold text-lg">{provider.objectData.Name}</h3>
                        <p className="text-sm text-[var(--text-secondary)]">{provider.objectData.BaseURL}</p>
                      </div>
                      <div className={`px-3 py-1 rounded-full text-xs ${provider.objectData.Status === 'active' ? 'bg-green-500 bg-opacity-20 text-green-400' : 'bg-gray-500 bg-opacity-20 text-gray-400'}`}>
                        {provider.objectData.Status}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => testProvider(provider)} disabled={testingProvider === provider.objectId} className="px-3 py-2 bg-blue-500 bg-opacity-20 text-blue-400 rounded-lg text-sm">
                        {testingProvider === provider.objectId ? 'Testing...' : 'Test'}
                      </button>
                      <button onClick={() => {setProviderForm({...provider.objectData, objectId: provider.objectId}); setShowProviderForm(true);}} className="px-3 py-2 bg-[var(--secondary-color)] rounded-lg text-sm">Edit</button>
                      <button onClick={() => deleteProvider(provider.objectId)} className="px-3 py-2 bg-red-500 bg-opacity-20 text-red-400 rounded-lg text-sm">Delete</button>
                    </div>

                  </div>
                ))}
              </div>

            </div>
          )}

          {activeTab === 'models' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">AI Models</h2>
                <button onClick={() => {setShowModelForm(true); setCustomTag(''); setModelForm({ProviderId: '', ModelID: '', FriendlyName: '', Status: 'enabled', PromptFormat: '', Parameters: '{}', Tags: [], TokenAmount: '1'});}} className="px-4 py-2 bg-[var(--primary-color)] rounded-lg">
                  <div className="icon-plus text-base inline-block mr-2"></div>Add Model
                </button>
              </div>

              {showModelForm && (
                <div className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6">
                  <h3 className="font-bold mb-4">{modelForm.objectId ? 'Edit' : 'New'} Model</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <select value={modelForm.ProviderId} onChange={(e) => setModelForm({...modelForm, ProviderId: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg">
                      <option value="">Select Provider</option>
                      {providers.map(p => (
                        <option key={p.objectId} value={p.objectId}>{p.objectData.Name}</option>
                      ))}
                    </select>
                    <input placeholder="Model ID" value={modelForm.ModelID} onChange={(e) => setModelForm({...modelForm, ModelID: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <input placeholder="Friendly Name" value={modelForm.FriendlyName} onChange={(e) => setModelForm({...modelForm, FriendlyName: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <input type="number" step="0.1" min="0.1" placeholder="Token amount (can be decimal: 1, 1.5, 2.5)" value={modelForm.TokenAmount || ''} onChange={(e) => setModelForm({...modelForm, TokenAmount: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <select value={modelForm.Status} onChange={(e) => setModelForm({...modelForm, Status: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg">
                      <option value="enabled">Enabled</option>
                      <option value="disabled">Disabled</option>
                    </select>
                    <input placeholder="Prompt Format (optional)" value={modelForm.PromptFormat} onChange={(e) => setModelForm({...modelForm, PromptFormat: e.target.value})} className="px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                    <textarea placeholder="Parameters (JSON)" value={modelForm.Parameters} onChange={(e) => setModelForm({...modelForm, Parameters: e.target.value})} className="md:col-span-2 px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" rows="2"></textarea>
                    <div className="md:col-span-2">
                      <label className="block text-sm mb-2">Tags</label>
                      <div className="space-y-3">
                        <div className="flex flex-wrap gap-2">
                          {['Recommended', 'Experimental', 'Fast', 'Budget'].map(tag => (
                            <button key={tag} onClick={() => setModelForm({...modelForm, Tags: modelForm.Tags?.includes(tag) ? modelForm.Tags.filter(t => t !== tag) : [...(modelForm.Tags || []), tag]})} className={`px-3 py-1 rounded text-sm ${modelForm.Tags?.includes(tag) ? 'bg-[var(--primary-color)] text-white' : 'bg-[var(--secondary-color)]'}`}>
                              {tag}
                            </button>
                          ))}
                        </div>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="Add custom tag..."
                            value={customTag}
                            onChange={(e) => setCustomTag(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' && customTag.trim()) {
                                e.preventDefault();
                                if (!modelForm.Tags?.includes(customTag.trim())) {
                                  setModelForm({...modelForm, Tags: [...(modelForm.Tags || []), customTag.trim()]});
                                }
                                setCustomTag('');
                              }
                            }}
                            className="flex-1 px-3 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg text-sm"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              if (customTag.trim() && !modelForm.Tags?.includes(customTag.trim())) {
                                setModelForm({...modelForm, Tags: [...(modelForm.Tags || []), customTag.trim()]});
                                setCustomTag('');
                              }
                            }}
                            className="px-4 py-2 bg-[var(--primary-color)] rounded-lg text-sm"
                          >
                            Add
                          </button>
                        </div>
                        {Array.isArray(modelForm.Tags) && modelForm.Tags.length > 0 && (
                          <div className="flex flex-wrap gap-2 pt-2 border-t border-[var(--border-color)]">
                            {modelForm.Tags.map((tag, i) => (
                              <div key={i} className="flex items-center gap-1 px-3 py-1 bg-[var(--primary-color)] text-white rounded text-sm">
                                <span>{tag}</span>
                                <button
                                  type="button"
                                  onClick={() => setModelForm({...modelForm, Tags: modelForm.Tags.filter((_, index) => index !== i)})}
                                  className="hover:text-red-300"
                                >
                                  <div className="icon-x text-xs"></div>
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <button onClick={saveModel} className="px-4 py-2 bg-[var(--primary-color)] rounded-lg">Save</button>
                    <button onClick={() => {setShowModelForm(false); setCustomTag('');}} className="px-4 py-2 bg-[var(--secondary-color)] rounded-lg">Cancel</button>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {models.map(model => {
                  const provider = providers.find(p => p.objectId === model.objectData.ProviderId);
                  return (
                    <div key={model.objectId} className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h3 className="font-bold">{model.objectData.FriendlyName}</h3>
                          <p className="text-xs text-[var(--text-secondary)]">{model.objectData.ModelID}</p>
                        </div>
                        <div className={`px-2 py-1 rounded text-xs ${model.objectData.Status === 'enabled' ? 'bg-green-500 bg-opacity-20 text-green-400' : 'bg-gray-500 bg-opacity-20 text-gray-400'}`}>
                          {model.objectData.Status}
                        </div>
                      </div>
                      
                      <div className="space-y-2 mb-3">
                        <div className="flex items-center gap-2 text-sm">
                          <div className="icon-building text-base text-[var(--primary-color)]"></div>
                          <span className="text-[var(--text-secondary)]">{provider?.objectData.Name || 'Unknown Provider'}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <div className="icon-coins text-base text-yellow-400"></div>
                          <span className="text-[var(--text-secondary)]">{model.objectData.TokenAmount || 1} tokens per {systemSettings.TokensPerContextInterval || 10} contexts</span>
                        </div>
                      </div>

                      {Array.isArray(model.objectData.Tags) && model.objectData.Tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mb-3">
                          {model.objectData.Tags.map((tag, i) => (
                            <span key={i} className="px-2 py-1 bg-[var(--primary-color)] bg-opacity-20 text-[var(--primary-color)] rounded text-xs">{tag}</span>
                          ))}
                        </div>
                      )}

                      <div className="flex gap-2">
                        <button onClick={() => {setCustomTag(''); setModelForm({...model.objectData, TokenAmount: model.objectData.TokenAmount?.toString() || '1', Tags: Array.isArray(model.objectData.Tags) ? model.objectData.Tags : [], objectId: model.objectId}); setShowModelForm(true);}} className="flex-1 px-3 py-2 bg-[var(--secondary-color)] rounded-lg text-sm">Edit</button>
                        <button onClick={() => deleteModel(model.objectId)} className="px-3 py-2 bg-red-500 bg-opacity-20 text-red-400 rounded-lg text-sm">Delete</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6">
              <h3 className="font-bold text-lg mb-4">System Settings</h3>
              <SettingsForm />
            </div>
          )}
        </div>

        {showEditTokenModal && selectedUserForTokenEdit && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => {setShowEditTokenModal(false); setSelectedUserForTokenEdit(null); setTokenEditAmount('');}}>
            <div className="bg-[var(--bg-dark)] rounded-xl p-6 max-w-md w-full mx-4 border border-[var(--border-color)]" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-xl font-bold mb-4">Edit User Tokens</h3>
              <p className="text-[var(--text-secondary)] mb-2">User: {selectedUserForTokenEdit.objectData.username}</p>
              <p className="text-sm text-[var(--text-secondary)] mb-4">Current: {selectedUserForTokenEdit.objectData.tokens || 0} tokens</p>
              <input 
                type="number"
                value={tokenEditAmount} 
                onChange={(e) => setTokenEditAmount(e.target.value)}
                placeholder="Enter new token amount"
                className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg mb-4"
              />
              <div className="flex gap-2">
                <button onClick={updateUserTokens} className="flex-1 px-4 py-3 bg-[var(--primary-color)] rounded-lg">
                  Update Tokens
                </button>
                <button onClick={() => {setShowEditTokenModal(false); setSelectedUserForTokenEdit(null); setTokenEditAmount('');}} className="flex-1 px-4 py-3 bg-[var(--secondary-color)] rounded-lg">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {showEditRoleModal && selectedUserForEdit && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => {setShowEditRoleModal(false); setSelectedUserForEdit(null);}}>
            <div className="bg-[var(--bg-dark)] rounded-xl p-6 max-w-md w-full mx-4 border border-[var(--border-color)]" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-xl font-bold mb-4">Edit User Role</h3>
              <p className="text-[var(--text-secondary)] mb-2">User: {selectedUserForEdit.objectData.username}</p>
              <p className="text-sm text-[var(--text-secondary)] mb-4">Email: {selectedUserForEdit.objectData.email}</p>
              <select 
                value={selectedUserForEdit.objectData.role || 'user'} 
                onChange={(e) => setSelectedUserForEdit({...selectedUserForEdit, objectData: {...selectedUserForEdit.objectData, role: e.target.value}})}
                className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg mb-4"
              >
                <option value="user">User</option>
                <option value="admin">Admin</option>
              </select>
              <div className="flex gap-2">
                <button onClick={updateUserRole} className="flex-1 px-4 py-3 bg-[var(--primary-color)] rounded-lg">
                  Update Role
                </button>
                <button onClick={() => {setShowEditRoleModal(false); setSelectedUserForEdit(null);}} className="flex-1 px-4 py-3 bg-[var(--secondary-color)] rounded-lg">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {showAdminRenameModal && projectToRename && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => {setShowAdminRenameModal(false); setProjectToRename(null); setNewProjectName('');}}>
            <div className="bg-[var(--bg-dark)] rounded-xl p-6 max-w-md w-full mx-4 border border-[var(--border-color)]" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-xl font-bold mb-4">Rename Project</h3>
              <p className="text-sm text-[var(--text-secondary)] mb-2">User: {projectToRename.userName}</p>
              <p className="text-xs text-[var(--text-secondary)] mb-4">Current name: {projectToRename.objectData.name || 'Untitled'}</p>
              <input
                type="text"
                value={newProjectName}
                onChange={(e) => setNewProjectName(e.target.value)}
                placeholder="Enter new project name"
                className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg mb-4"
              />
              <div className="flex gap-3">
                <button onClick={renameProject} className="flex-1 px-4 py-3 bg-[var(--primary-color)] rounded-lg">
                  Rename
                </button>
                <button 
                  onClick={() => {setShowAdminRenameModal(false); setProjectToRename(null); setNewProjectName('');}}
                  className="flex-1 px-4 py-3 bg-[var(--secondary-color)] rounded-lg"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {showAdminDeleteModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => {setShowAdminDeleteModal(false); setProjectToDelete(null);}}>
            <div className="bg-[var(--bg-dark)] rounded-xl p-6 max-w-md w-full mx-4 border border-[var(--border-color)]" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-xl font-bold mb-4">Delete Project{selectedProjects.length > 0 ? 's' : ''}</h3>
              <p className="text-[var(--text-secondary)] mb-6">
                {projectToDelete 
                  ? `Are you sure you want to delete "${projectToDelete.objectData.name || 'Untitled Project'}" by ${projectToDelete.userName}? This action cannot be undone.`
                  : `Are you sure you want to delete ${selectedProjects.length} selected project${selectedProjects.length > 1 ? 's' : ''}? This action cannot be undone.`
                }
              </p>
              <div className="flex gap-3">
                <button 
                  onClick={() => projectToDelete ? deleteProject(projectToDelete) : deleteSelectedProjects()}
                  className="flex-1 px-4 py-3 bg-red-500 rounded-lg hover:bg-red-600"
                >
                  Confirm Delete
                </button>
                <button 
                  onClick={() => {setShowAdminDeleteModal(false); setProjectToDelete(null);}}
                  className="flex-1 px-4 py-3 bg-[var(--secondary-color)] rounded-lg"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('AdminApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><AdminApp /></ErrorBoundary>);
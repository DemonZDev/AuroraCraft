class PhaseManager {
  constructor() {
    this.phases = [];
    this.currentPhaseIndex = -1;
    this.verifications = {};
  }

  createPlan(requirements) {
    this.phases = this.generatePhases(requirements);
    this.currentPhaseIndex = 0;
    return this.phases;
  }

  generatePhases(requirements) {
    const phases = [];
    
    phases.push({
      id: 1,
      name: 'Project Setup',
      tasks: [
        'Create project structure',
        'Setup pom.xml',
        'Create plugin.yml',
        'Create main class'
      ],
      verification: ['Structure exists', 'pom.xml valid', 'plugin.yml valid'],
      status: 'pending'
    });

    phases.push({
      id: 2,
      name: 'Core Implementation',
      tasks: [
        'Implement commands',
        'Create event listeners',
        'Add configuration'
      ],
      verification: ['Commands work', 'Events registered', 'Config loads'],
      status: 'pending'
    });

    phases.push({
      id: 3,
      name: 'Testing & Refinement',
      tasks: [
        'Test all features',
        'Fix bugs',
        'Optimize code'
      ],
      verification: ['All tests pass', 'No errors', 'Performance good'],
      status: 'pending'
    });

    return phases;
  }

  getCurrentPhase() {
    return this.phases[this.currentPhaseIndex];
  }

  async verifyPhase(phaseId) {
    const phase = this.phases.find(p => p.id === phaseId);
    if (!phase) return { success: false };

    if (!this.verifications[phaseId]) {
      this.verifications[phaseId] = { count: 0, results: [] };
    }

    this.verifications[phaseId].count++;
    
    const result = {
      verified: this.verifications[phaseId].count >= 2,
      checks: phase.verification,
      passed: []
    };

    return result;
  }

  async moveToNextPhase() {
    if (this.currentPhaseIndex < this.phases.length - 1) {
      this.currentPhaseIndex++;
      return this.getCurrentPhase();
    }
    return null;
  }

  getProgress() {
    const completed = this.phases.filter(p => p.status === 'completed').length;
    return {
      current: this.currentPhaseIndex + 1,
      total: this.phases.length,
      percentage: Math.round((completed / this.phases.length) * 100)
    };
  }
}
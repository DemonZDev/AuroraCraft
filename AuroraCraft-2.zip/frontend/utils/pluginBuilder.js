class PluginBuilder {
  constructor(software = 'paper') {
    this.software = software;
    this.apis = this.getAPIs();
  }

  getAPIs() {
    const apis = {
      paper: ['org.bukkit', 'io.papermc.paper'],
      spigot: ['org.bukkit'],
      bukkit: ['org.bukkit'],
      purpur: ['org.bukkit', 'io.papermc.paper', 'org.purpurmc.purpur'],
      folia: ['org.bukkit', 'io.papermc.paper', 'io.papermc.folia'],
      velocity: ['com.velocitypowered.api'],
      bungeecord: ['net.md_5.bungee.api']
    };
    return apis[this.software] || apis.paper;
  }

  generateMainClass(pluginName, packageName) {
    const className = pluginName.replace(/\s+/g, '');
    return `package ${packageName};

import org.bukkit.plugin.java.JavaPlugin;

public class ${className} extends JavaPlugin {
    
    @Override
    public void onEnable() {
        getLogger().info("${pluginName} has been enabled!");
    }
    
    @Override
    public void onDisable() {
        getLogger().info("${pluginName} has been disabled!");
    }
}`;
  }

  generatePluginYml(pluginName, mainClass, version = '1.0.0') {
    return `name: ${pluginName}
version: ${version}
main: ${mainClass}
api-version: '1.21'
author: AuroraCraft
description: Plugin created by AuroraCraft`;
  }

  generatePomXml(pluginName, groupId, artifactId) {
    const repoUrl = this.getRepositoryUrl();
    const dependency = this.getDependency();
    
    return `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>${groupId}</groupId>
    <artifactId>${artifactId}</artifactId>
    <version>1.0.0</version>
    <properties>
        <java.version>21</java.version>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>
    <repositories>
        <repository>
            <id>papermc</id>
            <url>${repoUrl}</url>
        </repository>
    </repositories>
    <dependencies>
        ${dependency}
    </dependencies>
    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.11.0</version>
                <configuration>
                    <source>21</source>
                    <target>21</target>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>`;
  }

  getRepositoryUrl() {
    const repos = {
      paper: 'https://repo.papermc.io/repository/maven-public/',
      spigot: 'https://hub.spigotmc.org/nexus/content/repositories/snapshots/',
      bungeecord: 'https://oss.sonatype.org/content/repositories/snapshots',
      velocity: 'https://repo.papermc.io/repository/maven-public/'
    };
    return repos[this.software] || repos.paper;
  }

  getDependency() {
    const deps = {
      paper: '<dependency><groupId>io.papermc.paper</groupId><artifactId>paper-api</artifactId><version>1.21-R0.1-SNAPSHOT</version><scope>provided</scope></dependency>',
      spigot: '<dependency><groupId>org.spigotmc</groupId><artifactId>spigot-api</artifactId><version>1.21-R0.1-SNAPSHOT</version><scope>provided</scope></dependency>'
    };
    return deps[this.software] || deps.paper;
  }
}
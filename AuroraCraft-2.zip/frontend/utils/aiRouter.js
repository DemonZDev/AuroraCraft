async function getActiveModels() {
  try {
    const modelsData = await trickleListObjects('models', 1000, true);
    
    const enabledModels = modelsData.items.filter(m => 
      m.objectData.Status === 'enabled' && 
      m.objectData.provider && 
      m.objectData.provider.Status === 'active'
    );
    
    return enabledModels.map(model => ({
      modelId: model.objectId,
      modelName: model.objectData.FriendlyName,
      modelIdentifier: model.objectData.ModelID,
      provider: model.objectData.provider,
      cost: model.objectData.UsageCost,
      parameters: model.objectData.Parameters,
      tags: model.objectData.Tags || []
    }));
  } catch (error) {
    console.error('Failed to load models:', error);
    return [];
  }
}

async function invokeModel(modelId, systemPrompt, userPrompt) {
  try {
    console.log('Invoking AI model:', modelId);
    
    // Use the backend API to invoke the model
    const content = await invokeAIAgent(systemPrompt, userPrompt, modelId);
    
    console.log('Successfully received AI response');
    return content;
  } catch (error) {
    console.error('Model invocation error:', error);
    throw error;
  }
}

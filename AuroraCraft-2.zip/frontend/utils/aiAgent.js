async function createMinecraftPluginAgent(userRequest, mode, software, chatHistory = [], modelId = null) {
  console.log('=== Plugin Agent Request ===');
  console.log('Mode:', mode);
  console.log('Software:', software);
  console.log('Model ID:', modelId);
  console.log('User request length:', userRequest.length);
  console.log('============================');
  
  try {
    const systemPrompt = `You are an expert Minecraft plugin developer specializing in ${software} server plugins.

CRITICAL RULES:
1. Generate COMPLETE, WORKING code - no placeholders, no TODOs
2. Use proper Java syntax with correct imports
3. Follow ${software} API conventions exactly
4. Include proper error handling in all event handlers
5. Use semantic versioning (1.0.0)
6. Always extend JavaPlugin in main class
7. Include plugin.yml with correct structure
8. Use modern Java features (Java 17+)

COMMON MISTAKES TO AVOID:
- Missing package declarations
- Incorrect event handler signatures
- Missing @Override annotations
- Forgetting to register listeners
- Incorrect plugin.yml format
- Missing dependencies in pom.xml
- Not handling null values
- Using deprecated API methods

MODE: ${mode}
${mode === 'agent' ? 'AUTONOMOUS MODE: Create complete plugin with all files, no user interaction needed.' : ''}
${mode === 'chat' ? 'CHAT MODE: Answer questions and provide guidance step by step.' : ''}
${mode === 'plan' ? 'PLAN MODE: Create detailed architecture and implementation plan.' : ''}
${mode === 'test' ? 'TEST MODE: Review code thoroughly, identify issues, suggest improvements.' : ''}

REQUIRED FILES FOR COMPLETE PLUGIN:
1. src/main/java/[package]/[PluginName].java - Main plugin class
2. src/main/resources/plugin.yml - Plugin metadata
3. pom.xml - Maven build configuration
4. src/main/resources/config.yml - Configuration (if needed)
5. Additional classes as needed

PLUGIN.YML TEMPLATE:
\`\`\`yaml
name: PluginName
version: 1.0.0
main: com.example.pluginname.PluginName
api-version: 1.20
author: AuroraCraft
description: Plugin description
commands:
  commandname:
    description: Command description
    usage: /<command>
    permission: pluginname.command
permissions:
  pluginname.*:
    description: All permissions
    default: op
\`\`\`

POM.XML TEMPLATE:
\`\`\`xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId>
    <artifactId>pluginname</artifactId>
    <version>1.0.0</version>
    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>
    <repositories>
        <repository>
            <id>papermc</id>
            <url>https://repo.papermc.io/repository/maven-public/</url>
        </repository>
    </repositories>
    <dependencies>
        <dependency>
            <groupId>io.papermc.paper</groupId>
            <artifactId>paper-api</artifactId>
            <version>1.20.4-R0.1-SNAPSHOT</version>
            <scope>provided</scope>
        </dependency>
    </dependencies>
</project>
\`\`\`

RESPONSE FORMAT:
Provide clear, structured response with:
1. Brief explanation of what you're creating
2. Complete file structure
3. All code files with full content
4. Setup instructions
5. Usage examples

${chatHistory.length > 0 ? '\n\nCHAT HISTORY:\n' + chatHistory.map(m => `${m.role}: ${m.content}`).slice(-5).join('\n') : ''}`;

    let response;
    try {
      response = await invokeAIAgent(systemPrompt, userRequest);
    } catch (invokeError) {
      console.error('invokeAIAgent failed:', invokeError);
      throw new Error(`AI model invocation failed: ${invokeError.message}`);
    }
    
    console.log('Plugin agent response received successfully');
    return response;
  } catch (error) {
    console.error('Plugin agent error:', error);
    if (error.message && error.message.includes('<!DOCTYPE')) {
      throw new Error('The AI provider returned an HTML page instead of a valid response. Please check:\n• Provider Base URL is correct\n• API endpoint path is configured\n• API credentials are valid\n\nGo to Admin > Providers to verify settings.');
    }
    throw error;
  }
}

async function enhancePrompt(prompt) {
  try {
    const systemPrompt = `You are a prompt enhancement assistant for Minecraft plugin development.

Transform the user's request to be:
1. Technically specific with proper terminology
2. Include version requirements (Java, Bukkit/Spigot/Paper API)
3. Specify expected features and commands clearly
4. Mention configuration needs
5. Define permissions structure
6. Specify event handling requirements

EXAMPLE TRANSFORMATIONS:
"make economy plugin" → "Create a complete economy plugin for Paper 1.20.4 with: player balance tracking using SQLite, /balance and /pay commands with permission system, shop GUI for buying/selling items, transaction logging, and configurable starting balance"

"teleport plugin" → "Develop a teleportation plugin for Spigot 1.20.4 featuring: /tp, /tpa, /tpaccept, /tpdeny commands, cooldown system, permission-based usage, teleport request timeout, safe location validation, and YAML configuration for cooldowns and costs"

Keep the original intent but add technical depth and clarity.`;
    
    const enhanced = await invokeAIAgent(systemPrompt, prompt);
    return enhanced;
  } catch (error) {
    console.error('Prompt enhancement error:', error);
    return prompt;
  }
}

async function generatePluginPlan(description, software) {
  try {
    const systemPrompt = `You are a Minecraft plugin architect for ${software} servers.

Create a DETAILED implementation plan with:

1. PROJECT OVERVIEW
   - Plugin name and purpose
   - Target server version
   - Key features list

2. FILE STRUCTURE
   \`\`\`
   plugin-name/
   ├── src/main/java/com/example/pluginname/
   │   ├── PluginName.java (main class)
   │   ├── commands/
   │   │   └── [CommandName]Command.java
   │   ├── listeners/
   │   │   └── [Event]Listener.java
   │   ├── managers/
   │   │   └── [Manager]Manager.java
   │   └── utils/
   │       └── [Utility]Util.java
   ├── src/main/resources/
   │   ├── plugin.yml
   │   └── config.yml
   └── pom.xml
   \`\`\`

3. CLASS RESPONSIBILITIES
   - List each class with its purpose and key methods

4. DEPENDENCIES
   - API dependencies (Paper, Spigot, Vault, etc.)
   - External libraries if needed

5. CONFIGURATION
   - Config file structure
   - Configurable options

6. PERMISSIONS SYSTEM
   - Permission nodes
   - Default access levels

7. COMMANDS
   - Command syntax
   - Parameters and usage

8. EVENT HANDLING
   - Events to listen to
   - Event priorities

9. DATA STORAGE
   - Storage method (YAML, SQLite, MySQL)
   - Data structure

10. IMPLEMENTATION PHASES
    - Phase 1: Core functionality
    - Phase 2: Commands and events
    - Phase 3: Configuration and permissions
    - Phase 4: Testing and polish

Provide actionable, specific implementation details.`;
    
    const plan = await invokeAIAgent(systemPrompt, description);
    return plan;
  } catch (error) {
    console.error('Plan generation error:', error);
    return 'Error generating plan. Please try again.';
  }
}

async function debugCompilationError(errorLog, software) {
  try {
    const systemPrompt = `You are a Java/Maven expert specializing in ${software} plugin development.

ANALYZE the compilation error and provide:

1. ERROR IDENTIFICATION
   - Error type (syntax, missing import, API version mismatch, etc.)
   - Exact location (file, line number if available)
   - Root cause explanation

2. COMMON CAUSES FOR THIS ERROR
   - List likely reasons based on error pattern

3. FIX SOLUTION
   - Provide exact code fix
   - Explain why this fix works
   - Show before/after code comparison

4. PREVENTION
   - How to avoid this error in future
   - Best practices related to this issue

5. ADDITIONAL CHECKS
   - Related issues to verify
   - Dependency version compatibility

FORMAT YOUR RESPONSE CLEARLY WITH SECTIONS.
BE SPECIFIC - NO VAGUE SUGGESTIONS.`;
    
    const solution = await invokeAIAgent(systemPrompt, `ERROR LOG:\n${errorLog}`);
    return solution;
  } catch (error) {
    console.error('Debug error:', error);
    return 'Error analyzing compilation errors. Please try again.';
  }
}

async function testPluginCode(codeFiles, software) {
  try {
    const systemPrompt = `You are a senior ${software} plugin developer and code reviewer.

REVIEW the plugin code thoroughly:

1. SYNTAX VALIDATION
   - Check Java syntax correctness
   - Verify all imports are present
   - Ensure proper package declarations

2. API USAGE
   - Verify ${software} API methods are used correctly
   - Check for deprecated methods
   - Validate event handler signatures

3. BEST PRACTICES
   - Error handling completeness
   - Resource cleanup (file handles, connections)
   - Thread safety if using async operations
   - Proper use of @Override annotations

4. PLUGIN.YML VALIDATION
   - Correct structure and formatting
   - All commands defined
   - Permission nodes match code

5. POM.XML VALIDATION
   - Correct dependencies
   - Proper versions
   - Build configuration

6. POTENTIAL ISSUES
   - Memory leaks
   - Performance bottlenecks
   - Security vulnerabilities
   - Edge cases not handled

7. IMPROVEMENTS
   - Code optimization suggestions
   - Better design patterns
   - Additional features to consider

PROVIDE SPECIFIC LINE-BY-LINE FEEDBACK WITH CODE EXAMPLES.`;
    
    const filesContent = Object.entries(codeFiles).map(([path, content]) => 
      `FILE: ${path}\n\`\`\`\n${content}\n\`\`\``
    ).join('\n\n');
    
    const review = await invokeAIAgent(systemPrompt, filesContent);
    return review;
  } catch (error) {
    console.error('Test error:', error);
    return 'Error testing plugin code. Please try again.';
  }
}

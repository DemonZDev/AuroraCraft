class FileManager {
  constructor(sessionId) {
    this.sessionId = sessionId;
    this.fileTree = {};
    this.files = new Map();
  }

  async createFile(path, content = '') {
    const normalized = this.normalizePath(path);
    this.files.set(normalized, {
      path: normalized,
      content,
      created: new Date().toISOString(),
      modified: new Date().toISOString()
    });
    this.updateFileTree();
    return { success: true, path: normalized };
  }

  async readFile(path) {
    const normalized = this.normalizePath(path);
    const file = this.files.get(normalized);
    return file ? file.content : null;
  }

  async updateFile(path, content) {
    const normalized = this.normalizePath(path);
    const file = this.files.get(normalized);
    if (file) {
      file.content = content;
      file.modified = new Date().toISOString();
      return { success: true };
    }
    return { success: false, error: 'File not found' };
  }

  async deleteFile(path) {
    const normalized = this.normalizePath(path);
    const deleted = this.files.delete(normalized);
    if (deleted) this.updateFileTree();
    return { success: deleted };
  }

  async renameFile(oldPath, newPath) {
    const file = this.files.get(this.normalizePath(oldPath));
    if (file) {
      this.files.delete(this.normalizePath(oldPath));
      file.path = this.normalizePath(newPath);
      this.files.set(file.path, file);
      this.updateFileTree();
      return { success: true };
    }
    return { success: false };
  }

  async createFolder(path) {
    return { success: true, path };
  }

  listFiles(directory = '/') {
    const files = [];
    for (const [path, file] of this.files.entries()) {
      if (path.startsWith(directory)) {
        files.push({
          name: this.getFileName(path),
          path,
          type: 'file',
          size: file.content.length
        });
      }
    }
    return files;
  }

  normalizePath(path) {
    return path.replace(/\\/g, '/').replace(/\/+/g, '/');
  }

  getFileName(path) {
    return path.split('/').pop();
  }

  updateFileTree() {
    this.fileTree = this.buildTree();
  }

  buildTree() {
    const tree = { name: 'root', children: [] };
    for (const path of this.files.keys()) {
      this.addToTree(tree, path.split('/'), this.files.get(path));
    }
    return tree;
  }

  addToTree(node, parts, file) {
    if (parts.length === 0) return;
    const part = parts[0];
    let child = node.children?.find(c => c.name === part);
    if (!child) {
      child = { name: part, children: [] };
      if (!node.children) node.children = [];
      node.children.push(child);
    }
    if (parts.length > 1) {
      this.addToTree(child, parts.slice(1), file);
    } else {
      child.file = file;
    }
  }

  getFileTree() {
    return this.fileTree;
  }
}
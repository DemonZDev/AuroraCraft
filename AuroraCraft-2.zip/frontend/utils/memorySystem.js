class MemorySystem {
  constructor(sessionId) {
    this.sessionId = sessionId;
    this.memories = {
      session: {},
      permanent: {},
      facts: [],
      context: []
    };
  }

  async save(key, value, type = 'session') {
    if (type === 'session') {
      this.memories.session[key] = value;
    } else {
      this.memories.permanent[key] = value;
    }
    await this.persist();
  }

  async recall(key, type = 'session') {
    if (type === 'session') {
      return this.memories.session[key];
    }
    return this.memories.permanent[key];
  }

  async addFact(fact) {
    this.memories.facts.push({
      content: fact,
      timestamp: new Date().toISOString()
    });
    await this.persist();
  }

  async addContext(context) {
    this.memories.context.push({
      content: context,
      timestamp: new Date().toISOString()
    });
    if (this.memories.context.length > 50) {
      this.memories.context = this.memories.context.slice(-50);
    }
    await this.persist();
  }

  async searchMemory(query) {
    const results = [];
    
    for (const [key, value] of Object.entries(this.memories.session)) {
      if (JSON.stringify(value).toLowerCase().includes(query.toLowerCase())) {
        results.push({ key, value, type: 'session' });
      }
    }
    
    for (const fact of this.memories.facts) {
      if (fact.content.toLowerCase().includes(query.toLowerCase())) {
        results.push({ ...fact, type: 'fact' });
      }
    }
    
    return results;
  }

  async persist() {
    try {
      const user = JSON.parse(localStorage.getItem('currentUser'));
      if (user) {
        await trickleUpdateObject(
          `session:${user.objectId}`,
          this.sessionId,
          { memory: this.memories }
        );
      }
    } catch (error) {
      console.error('Memory persistence error:', error);
    }
  }

  async load() {
    try {
      const user = JSON.parse(localStorage.getItem('currentUser'));
      if (user) {
        const session = await trickleGetObject(
          `session:${user.objectId}`,
          this.sessionId
        );
        if (session.objectData.memory) {
          this.memories = session.objectData.memory;
        }
      }
    } catch (error) {
      console.error('Memory load error:', error);
    }
  }

  getRecentContext(limit = 10) {
    return this.memories.context.slice(-limit);
  }

  getAllFacts() {
    return this.memories.facts;
  }
}
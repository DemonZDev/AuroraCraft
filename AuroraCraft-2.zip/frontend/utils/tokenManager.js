class TokenManager {
  async getUserTokenBalance(userId) {
    try {
      const user = await trickleGetObject('user', userId);
      return user.objectData.tokens || 0;
    } catch (error) {
      console.error('Failed to get token balance:', error);
      return 0;
    }
  }

  async isAdmin(userId) {
    try {
      const user = await trickleGetObject('user', userId);
      return user.objectData.role === 'admin';
    } catch (error) {
      return false;
    }
  }

  async getModelTokenCost(modelId) {
    try {
      const model = await trickleGetObject('ai_model', modelId);
      return model.objectData.TokenAmount || 1;
    } catch (error) {
      console.error('Failed to get model token cost:', error);
      return 1;
    }
  }

  async getContextInterval() {
    try {
      const settings = await trickleListObjects('system_settings', 1, true);
      if (settings.items.length > 0) {
        return settings.items[0].objectData.TokensPerContextInterval || 10;
      }
      return 10;
    } catch (error) {
      console.error('Failed to get context interval:', error);
      return 10;
    }
  }

  async canUserSendMessage(userId, modelId) {
    if (await this.isAdmin(userId)) {
      return { allowed: true, isAdmin: true };
    }

    const balance = await this.getUserTokenBalance(userId);
    const tokenAmount = await this.getModelTokenCost(modelId);
    
    return { 
      allowed: balance >= tokenAmount, 
      balance,
      tokenCost: tokenAmount,
      isAdmin: false 
    };
  }

  async deductTokens(userId, sessionId, modelId, promptLength, responseLength) {
    try {
      if (await this.isAdmin(userId)) {
        return { success: true, isAdmin: true };
      }

      const user = await trickleGetObject('user', userId);
      const contextInterval = await this.getContextInterval();
      const tokenAmount = await this.getModelTokenCost(modelId);
      
      const sessionKey = `contextCount_${sessionId}`;
      let contextCount = parseInt(user.objectData[sessionKey] || 0);
      contextCount++;

      let tokensToDeduct = 0;
      if (contextCount >= contextInterval) {
        tokensToDeduct = tokenAmount;
        contextCount = 0;
      }

      const currentTokens = user.objectData.tokens || 0;
      
      if (tokensToDeduct > 0 && currentTokens < tokensToDeduct) {
        return { 
          success: false, 
          error: 'Insufficient tokens',
          balance: currentTokens 
        };
      }

      const newBalance = currentTokens - tokensToDeduct;
      const totalUsed = user.objectData.totalTokensUsed || 0;
      const newTotalUsed = totalUsed + tokensToDeduct;

      const updateData = {
        ...user.objectData,
        tokens: newBalance,
        totalTokensUsed: newTotalUsed
      };
      updateData[sessionKey] = contextCount;

      await trickleUpdateObject('user', userId, updateData);

      if (tokensToDeduct > 0) {
        await trickleCreateObject('token_transaction', {
          userId,
          sessionId: sessionId || 'unknown',
          modelId: modelId || 'unknown',
          tokensUsed: tokensToDeduct,
          promptLength: promptLength || 0,
          responseLength: responseLength || 0,
          transactionType: 'usage'
        });
      }

      return { 
        success: true, 
        newBalance,
        tokensUsed: tokensToDeduct,
        contextCount,
        nextDeductionAt: contextInterval
      };
    } catch (error) {
      console.error('Token deduction failed:', error);
      return { success: false, error: error.message };
    }
  }

  async addTokens(userId, amount, transactionType = 'admin_grant') {
    try {
      const user = await trickleGetObject('user', userId);
      const currentTokens = user.objectData.tokens || 0;
      const newBalance = currentTokens + amount;

      await trickleUpdateObject('user', userId, {
        ...user.objectData,
        tokens: newBalance
      });

      await trickleCreateObject('token_transaction', {
        userId,
        sessionId: 'system',
        modelId: 'system',
        tokensUsed: -amount,
        promptLength: 0,
        responseLength: 0,
        transactionType
      });

      return { success: true, newBalance };
    } catch (error) {
      console.error('Token addition failed:', error);
      return { success: false, error: error.message };
    }
  }

  async getTransactionHistory(userId, limit = 50) {
    try {
      const transactions = await trickleListObjects('token_transaction', limit, true);
      return transactions.items.filter(t => t.objectData.userId === userId);
    } catch (error) {
      console.error('Failed to get transaction history:', error);
      return [];
    }
  }
}

const tokenManager = new TokenManager();
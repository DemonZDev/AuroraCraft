function Hero() {
  try {
    return (
      <section className="py-20 px-4 text-center" data-name="hero" data-file="components/Hero.js">
        <div className="max-w-4xl mx-auto">
          <div className="inline-block px-4 py-2 bg-[var(--secondary-color)] rounded-full text-sm font-medium mb-6 border border-[var(--border-color)]">
            <span className="text-[var(--accent-color)]">✨</span> AI-Powered Plugin Development
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Autonomous AI
            <br />
            <span className="text-[var(--primary-color)]">Plugin Creator</span>
          </h1>
          
          <p className="text-xl text-[var(--text-secondary)] mb-8 max-w-2xl mx-auto">
            Full agentic AI system that creates, plans, and manages complex Minecraft plugins. 
            Deep reasoning, blazing memory, and autonomous execution.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => window.location.href = 'ide.html'} className="btn-primary">
              Start Building
              <span className="ml-2">→</span>
            </button>
            <button onClick={() => window.location.href = 'sessions.html'} className="btn-secondary">
              View Sessions
            </button>
          </div>

          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-[var(--primary-color)] mb-2">Java 21</div>
              <div className="text-sm text-[var(--text-secondary)]">Latest Version</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-[var(--primary-color)] mb-2">Maven</div>
              <div className="text-sm text-[var(--text-secondary)]">Build System</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-[var(--primary-color)] mb-2">Multi-LLM</div>
              <div className="text-sm text-[var(--text-secondary)]">AI Models</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-[var(--primary-color)] mb-2">Real-time</div>
              <div className="text-sm text-[var(--text-secondary)]">Collaboration</div>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Hero component error:', error);
    return null;
  }
}
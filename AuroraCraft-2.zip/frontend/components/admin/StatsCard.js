function StatsCard({ icon, label, value, color }) {
  try {
    const iconColorMap = {
      'bg-blue-500': 'text-blue-400',
      'bg-green-500': 'text-green-400',
      'bg-purple-500': 'text-purple-400',
      'bg-orange-500': 'text-orange-400'
    };

    return (
      <div className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6" data-name="stats-card" data-file="components/admin/StatsCard.js">
        <div className="flex items-center justify-between mb-4">
          <div className={`w-12 h-12 ${color} bg-opacity-10 rounded-lg flex items-center justify-center`}>
            <div className={`icon-${icon} text-xl ${iconColorMap[color]}`}></div>
          </div>
        </div>
        <div className="text-3xl font-bold mb-1">{value}</div>
        <div className="text-sm text-[var(--text-secondary)]">{label}</div>
      </div>
    );
  } catch (error) {
    console.error('StatsCard error:', error);
    return null;
  }
}

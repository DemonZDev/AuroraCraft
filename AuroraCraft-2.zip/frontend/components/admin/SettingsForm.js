function SettingsForm() {
  try {
    const [settings, setSettings] = React.useState({
      siteName: localStorage.getItem('siteName') || 'AuroraCraft',
      maxSessions: localStorage.getItem('maxSessions') || '10',
      aiName: localStorage.getItem('aiName') || 'AuroraCraft',
      siteLogo: localStorage.getItem('siteLogo') || null,
      aiAvatar: localStorage.getItem('aiAvatar') || null
    });
    const siteLogoRef = React.useRef(null);
    const aiAvatarRef = React.useRef(null);

    const handleFileUpload = (type, e) => {
      const file = e.target.files[0];
      if (file) {
        if (file.size > 5 * 1024 * 1024) {
          alert('File size must be less than 5MB');
          return;
        }
        const reader = new FileReader();
        reader.onloadend = () => {
          setSettings(prev => ({...prev, [type]: reader.result}));
        };
        reader.readAsDataURL(file);
      }
    };

    const saveSettings = () => {
      localStorage.setItem('siteName', settings.siteName);
      localStorage.setItem('maxSessions', settings.maxSessions);
      localStorage.setItem('aiName', settings.aiName);
      if (settings.siteLogo) localStorage.setItem('siteLogo', settings.siteLogo);
      if (settings.aiAvatar) localStorage.setItem('aiAvatar', settings.aiAvatar);
      alert('Settings saved successfully! Please refresh the page to see changes.');
    };

    return (
      <div className="space-y-6" data-name="settings-form" data-file="components/admin/SettingsForm.js">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium mb-2">Site Name</label>
            <input value={settings.siteName} onChange={(e) => setSettings({...settings, siteName: e.target.value})} className="w-full px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">AI Assistant Name</label>
            <input value={settings.aiName} onChange={(e) => setSettings({...settings, aiName: e.target.value})} className="w-full px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Max Sessions Per User</label>
          <input type="number" value={settings.maxSessions} onChange={(e) => setSettings({...settings, maxSessions: e.target.value})} className="w-full px-4 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium mb-3">Site Logo (max 5MB)</label>
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center overflow-hidden">
                {settings.siteLogo ? (
                  <img src={settings.siteLogo} alt="Logo" className="w-full h-full object-cover" />
                ) : (
                  <div className="icon-image text-2xl text-white"></div>
                )}
              </div>
              <button type="button" onClick={() => siteLogoRef.current?.click()} className="px-4 py-2 bg-[var(--primary-color)] rounded-lg">Upload</button>
              <input ref={siteLogoRef} type="file" accept="image/*" onChange={(e) => handleFileUpload('siteLogo', e)} className="hidden" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-3">AI Avatar (max 5MB)</label>
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-[var(--primary-color)] rounded-lg flex items-center justify-center overflow-hidden">
                {settings.aiAvatar ? (
                  <img src={settings.aiAvatar} alt="AI Avatar" className="w-full h-full object-cover" />
                ) : (
                  <div className="icon-bot text-2xl text-white"></div>
                )}
              </div>
              <button type="button" onClick={() => aiAvatarRef.current?.click()} className="px-4 py-2 bg-[var(--primary-color)] rounded-lg">Upload</button>
              <input ref={aiAvatarRef} type="file" accept="image/*" onChange={(e) => handleFileUpload('aiAvatar', e)} className="hidden" />
            </div>
          </div>
        </div>

        <button onClick={saveSettings} className="px-6 py-3 bg-[var(--primary-color)] rounded-lg hover:bg-[var(--accent-color)] transition-all">
          Save Settings
        </button>
      </div>
    );
  } catch (error) {
    console.error('SettingsForm error:', error);
    return null;
  }
}
// Partial content, replace this line and continue implementing the file.
function RegisterForm() {
  try {
    const [formData, setFormData] = React.useState({
      username: '',
      email: '',
      password: '',
      confirmPassword: ''
    });
    const [errors, setErrors] = React.useState({});
    const [isLoading, setIsLoading] = React.useState(false);

    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData(prev => ({ ...prev, [name]: value }));
      if (errors[name]) {
        setErrors(prev => ({ ...prev, [name]: '' }));
      }
    };

    const handleSubmit = async (e) => {
      e.preventDefault();
      const validationErrors = validateRegisterForm(formData);
      
      if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        return;
      }

      setIsLoading(true);
      try {
        const response = await register(formData.username, formData.email, formData.password);
        
        // Store user data in localStorage
        localStorage.setItem('currentUser', JSON.stringify(response.user));
        
        // Redirect to sessions page
        window.location.href = 'sessions.html';
      } catch (error) {
        console.error('Registration error:', error);
        setErrors({ submit: error.message || 'Registration failed. Please try again.' });
      } finally {
        setIsLoading(false);
      }
    };

    return (
      <div className="w-full max-w-md bg-[var(--bg-dark)] rounded-xl p-8 border border-[var(--border-color)]" data-name="register-form" data-file="components/auth/RegisterForm.js">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[var(--primary-color)] rounded-xl flex items-center justify-center mx-auto mb-4">
            <div className="icon-sparkles text-3xl text-white"></div>
          </div>
          <h1 className="text-2xl font-bold mb-2">Create Account</h1>
          <p className="text-[var(--text-secondary)] text-sm">Join AuroraCraft today</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Username</label>
            <input
              type="text"
              name="username"
              value={formData.username}
              onChange={handleChange}
              className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              placeholder="Enter username"
            />
            {errors.username && <p className="text-red-400 text-sm mt-1">{errors.username}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              placeholder="Enter email"
            />
            {errors.email && <p className="text-red-400 text-sm mt-1">{errors.email}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              placeholder="Enter password (min 6 characters)"
            />
            {errors.password && <p className="text-red-400 text-sm mt-1">{errors.password}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Confirm Password</label>
            <input
              type="password"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              placeholder="Confirm password"
            />
            {errors.confirmPassword && <p className="text-red-400 text-sm mt-1">{errors.confirmPassword}</p>}
          </div>

          {errors.submit && <p className="text-red-400 text-sm">{errors.submit}</p>}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-[var(--primary-color)] rounded-lg font-medium hover:bg-[var(--accent-color)] transition-all disabled:opacity-50"
          >
            {isLoading ? 'Creating Account...' : 'Register'}
          </button>
        </form>

        <p className="text-center text-sm text-[var(--text-secondary)] mt-6">
          Already have an account? <a href="login.html" className="text-[var(--primary-color)] hover:underline">Login</a>
        </p>
      </div>
    );
  } catch (error) {
    console.error('RegisterForm error:', error);
    return null;
  }
}

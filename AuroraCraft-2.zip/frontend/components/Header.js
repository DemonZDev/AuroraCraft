function Header() {
  try {
    const [isMenuOpen, setIsMenuOpen] = React.useState(false);
    const [currentUser, setCurrentUser] = React.useState(null);

    React.useEffect(() => {
      const user = localStorage.getItem('currentUser');
      if (user) {
        setCurrentUser(JSON.parse(user));
      }
    }, []);

    // Helper to check if user is admin
    const isAdmin = () => {
      const user = localStorage.getItem('currentUser');
      if (user) {
        const userData = JSON.parse(user);
        // Check both possible structures
        return userData.role === 'admin' || userData.user?.role === 'admin';
      }
      return false;
    };

    // Helper to get user tokens (null for admins)
    const getUserTokens = () => {
      const user = localStorage.getItem('currentUser');
      if (user) {
        const userData = JSON.parse(user);
        const role = userData.role || userData.user?.role;
        if (role === 'admin') {
          return null; // Admins don't see tokens
        }
        return userData.tokens || userData.user?.tokens || 0;
      }
      return 0;
    };

    const tokens = getUserTokens();

    return (
      <header className="border-b border-[var(--border-color)] bg-[var(--bg-dark)] sticky top-0 z-50" data-name="header" data-file="components/Header.js">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-[var(--primary-color)] rounded-lg flex items-center justify-center">
              <div className="icon-sparkles text-xl text-white"></div>
            </div>
            <span className="text-xl font-bold">AuroraCraft</span>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <a href="index.html" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors">Home</a>
            <a href="ide.html" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors">Chat</a>
            {currentUser && <a href="sessions.html" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors">Sessions</a>}
            {currentUser && <a href="account.html" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors">Account</a>}
            {isAdmin() && (
              <a href="admin.html" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors">Admin</a>
            )}
            {tokens !== null && (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-[var(--secondary-color)] rounded-lg border border-[var(--border-color)]">
                <div className="icon-coins text-base text-yellow-400"></div>
                <span className="text-sm font-medium">{tokens.toFixed(1)}</span>
              </div>
            )}
            {localStorage.getItem('currentUser') ? (
              <button onClick={() => { localStorage.removeItem('currentUser'); localStorage.removeItem('authToken'); window.location.reload(); }} className="btn-secondary">
                Logout
              </button>
            ) : (
              <>
                <a href="login.html" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]">Login</a>
                <a href="register.html" className="btn-primary">Register</a>
              </>
            )}
          </nav>

          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            <div className={`icon-${isMenuOpen ? 'x' : 'menu'} text-2xl`}></div>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden border-t border-[var(--border-color)] bg-[var(--bg-dark)] px-4 py-4">
            <nav className="flex flex-col gap-4">
              <a href="index.html" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]">Home</a>
              <a href="ide.html" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]">Chat</a>
              {currentUser && <a href="sessions.html" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]">Sessions</a>}
              {currentUser && <a href="account.html" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]">Account</a>}
              {isAdmin() && (
                <a href="admin.html" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]">Admin</a>
              )}
              {tokens !== null && (
                <div className="flex items-center gap-2 px-3 py-2 bg-[var(--secondary-color)] rounded-lg border border-[var(--border-color)]">
                  <div className="icon-coins text-base text-yellow-400"></div>
                  <span className="font-medium">{tokens.toFixed(1)} tokens</span>
                </div>
              )}
              {localStorage.getItem('currentUser') ? (
                <button onClick={() => { localStorage.removeItem('currentUser'); localStorage.removeItem('authToken'); window.location.reload(); }} className="btn-secondary w-full">
                  Logout
                </button>
              ) : (
                <>
                  <a href="login.html" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]">Login</a>
                  <a href="register.html" className="btn-primary w-full">Register</a>
                </>
              )}
            </nav>
          </div>
        )}
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}

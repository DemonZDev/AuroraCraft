function Footer() {
  try {
    return (
      <footer className="border-t border-[var(--border-color)] bg-[var(--bg-dark)] py-12 px-4" data-name="footer" data-file="components/Footer.js">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-[var(--primary-color)] rounded-lg flex items-center justify-center">
                  <div className="icon-sparkles text-lg text-white"></div>
                </div>
                <span className="text-lg font-bold">AuroraCraft</span>
              </div>
              <p className="text-[var(--text-secondary)] text-sm">
                AI-powered Minecraft plugin development platform
              </p>
            </div>
            
            <div>
              <h4 className="font-bold mb-3">Product</h4>
              <ul className="space-y-2 text-sm text-[var(--text-secondary)]">
                <li><a href="ide.html" className="hover:text-[var(--text-primary)]">IDE</a></li>
                <li><a href="sessions.html" className="hover:text-[var(--text-primary)]">Sessions</a></li>
                <li><a href="#" className="hover:text-[var(--text-primary)]">Documentation</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold mb-3">Resources</h4>
              <ul className="space-y-2 text-sm text-[var(--text-secondary)]">
                <li><a href="#" className="hover:text-[var(--text-primary)]">Tutorials</a></li>
                <li><a href="#" className="hover:text-[var(--text-primary)]">API Reference</a></li>
                <li><a href="#" className="hover:text-[var(--text-primary)]">Examples</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold mb-3">Company</h4>
              <ul className="space-y-2 text-sm text-[var(--text-secondary)]">
                <li><a href="#" className="hover:text-[var(--text-primary)]">About</a></li>
                <li><a href="#" className="hover:text-[var(--text-primary)]">Contact</a></li>
                <li><a href="admin.html" className="hover:text-[var(--text-primary)]">Admin</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-[var(--border-color)] pt-8 text-center text-sm text-[var(--text-secondary)]">
            © 2025 AuroraCraft. All rights reserved.
          </div>
        </div>
      </footer>
    );
  } catch (error) {
    console.error('Footer component error:', error);
    return null;
  }
}
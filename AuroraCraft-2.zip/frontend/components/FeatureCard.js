function FeatureCard({ icon, title, description }) {
  try {
    return (
      <div className="card hover:border-[var(--primary-color)] transition-all duration-200" data-name="feature-card" data-file="components/FeatureCard.js">
        <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center mb-4">
          <div className={`icon-${icon} text-xl text-[var(--primary-color)]`}></div>
        </div>
        <h3 className="text-xl font-bold mb-3">{title}</h3>
        <p className="text-[var(--text-secondary)]">{description}</p>
      </div>
    );
  } catch (error) {
    console.error('FeatureCard component error:', error);
    return null;
  }
}
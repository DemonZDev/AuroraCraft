function SessionCard({ session }) {
  try {
    const formatDate = (dateString) => {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
    };

    return (
      <div className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6 hover:border-[var(--primary-color)] transition-all cursor-pointer" 
           onClick={() => window.location.href = `ide.html?session=${session.objectId}`} 
           data-name="session-card" 
           data-file="components/sessions/SessionCard.js">
        <div className="flex items-start justify-between mb-4">
          <div className="w-10 h-10 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center">
            <div className="icon-folder text-lg text-[var(--primary-color)]"></div>
          </div>
          <button className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]" onClick={(e) => e.stopPropagation()}>
            <div className="icon-more-vertical text-lg"></div>
          </button>
        </div>
        
        <h3 className="text-lg font-bold mb-2">{session.objectData.name || 'Untitled Session'}</h3>
        
        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2 text-[var(--text-secondary)]">
            <div className="icon-calendar text-base"></div>
            <span>{formatDate(session.createdAt)}</span>
          </div>
          <div className="flex items-center gap-2 text-[var(--text-secondary)]">
            <div className="icon-cpu text-base"></div>
            <span>{session.objectData.model || 'GPT-4'}</span>
          </div>
          <div className="flex items-center gap-2 text-[var(--text-secondary)]">
            <div className="icon-message-circle text-base"></div>
            <span>{session.objectData.messageCount || 0} messages</span>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('SessionCard error:', error);
    return null;
  }
}
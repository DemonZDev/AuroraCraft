function ChatPanel({ messages, onToggleSidebar, onToggleEditor }) {
  try {
    const chatEndRef = React.useRef(null);

    React.useEffect(() => {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    return (
      <div className="flex-1 flex flex-col bg-[var(--bg-darker)]" data-name="chat-panel" data-file="components/ide/ChatPanel.js">
        <div className="p-4 border-b border-[var(--border-color)] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={onToggleSidebar}>
              <div className="icon-panel-left text-lg"></div>
            </button>
            <h2 className="font-bold">AI Assistant</h2>
          </div>
          <button onClick={onToggleEditor} className="px-4 py-2 bg-[var(--secondary-color)] rounded-lg text-sm">
            <div className="icon-code-2 text-base inline-block mr-2"></div>
            Code Editor
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6">
          {messages.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-16 h-16 bg-[var(--primary-color)] bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                <div className="icon-sparkles text-3xl text-[var(--primary-color)]"></div>
              </div>
              <h3 className="text-xl font-bold mb-2">Welcome to AuroraCraft IDE</h3>
              <p className="text-[var(--text-secondary)] max-w-md mx-auto">
                Start a conversation to build your Minecraft plugin. I'll guide you through planning, coding, and compilation.
              </p>
            </div>
          ) : (
            <div className="space-y-6 max-w-3xl mx-auto">
              {messages.map((msg, index) => (
                <div key={index} className={`flex gap-4 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                  {msg.role === 'ai' && (
                    <div className="w-8 h-8 bg-[var(--primary-color)] rounded-lg flex items-center justify-center flex-shrink-0">
                      <div className="icon-bot text-sm text-white"></div>
                    </div>
                  )}
                  <div className={`px-4 py-3 rounded-lg max-w-2xl ${
                    msg.role === 'user' 
                      ? 'bg-[var(--primary-color)] text-white' 
                      : 'bg-[var(--bg-dark)] border border-[var(--border-color)]'
                  }`}>
                    {msg.content}
                  </div>
                  {msg.role === 'user' && (
                    <div className="w-8 h-8 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center flex-shrink-0">
                      <div className="icon-user text-sm"></div>
                    </div>
                  )}
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('ChatPanel component error:', error);
    return null;
  }
}
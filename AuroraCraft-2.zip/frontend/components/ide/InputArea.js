function InputArea({ onSendMessage }) {
  try {
    const [input, setInput] = React.useState('');
    const [mode, setMode] = React.useState('chat');
    const [model, setModel] = React.useState('gpt-4');
    const [isLoading, setIsLoading] = React.useState(false);

    const handleSend = () => {
      if (input.trim() && !isLoading) {
        onSendMessage({ role: 'user', content: input });
        setInput('');
      }
    };

    const handleEnhance = async () => {
      if (input.trim()) {
        setIsLoading(true);
        const enhanced = await enhancePrompt(input);
        setInput(enhanced);
        setIsLoading(false);
      }
    };

    return (
      <div className="border-t border-[var(--border-color)] bg-[var(--bg-dark)] p-4" data-name="input-area" data-file="components/ide/InputArea.js">
        <div className="max-w-4xl mx-auto space-y-3">
          <div className="flex gap-2">
            <select 
              value={mode} 
              onChange={(e) => setMode(e.target.value)}
              className="px-3 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg text-sm"
            >
              <option value="chat">Chat Mode</option>
              <option value="plan">Plan Mode</option>
              <option value="debug">Debug Mode</option>
            </select>
            
            <select 
              value={model} 
              onChange={(e) => setModel(e.target.value)}
              className="px-3 py-2 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg text-sm"
            >
              <option value="gpt-4">GPT-4</option>
              <option value="claude-3">Claude 3</option>
              <option value="gemini">Gemini</option>
              <option value="deepseek">DeepSeek</option>
            </select>

            <button 
              onClick={handleEnhance}
              disabled={!input.trim() || isLoading}
              className="px-4 py-2 bg-[var(--secondary-color)] rounded-lg text-sm disabled:opacity-50"
            >
              <div className="icon-sparkles text-base inline-block mr-2"></div>
              Enhance
            </button>
          </div>

          <div className="flex gap-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())}
              placeholder="Describe your plugin idea..."
              className="flex-1 px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg resize-none focus:outline-none focus:border-[var(--primary-color)]"
              rows="3"
            />
            <button 
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="px-6 bg-[var(--primary-color)] rounded-lg disabled:opacity-50"
            >
              <div className="icon-send text-xl"></div>
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('InputArea component error:', error);
    return null;
  }
}

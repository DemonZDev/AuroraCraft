function Sidebar({ files, onFileSelect, onToggle }) {
  try {
    return (
      <div className="w-64 border-r border-[var(--border-color)] bg-[var(--bg-dark)] flex flex-col" data-name="sidebar" data-file="components/ide/Sidebar.js">
        <div className="p-4 border-b border-[var(--border-color)] flex items-center justify-between">
          <h3 className="font-bold">Project Files</h3>
          <button onClick={onToggle}>
            <div className="icon-panel-left-close text-lg"></div>
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
          {files.length === 0 ? (
            <div className="text-[var(--text-secondary)] text-sm text-center py-8">
              No files yet. Start chatting to create your plugin!
            </div>
          ) : (
            <div className="space-y-1">
              {files.map((file, index) => (
                <button
                  key={index}
                  onClick={() => onFileSelect(file)}
                  className="w-full text-left px-3 py-2 rounded hover:bg-[var(--bg-darker)] text-sm flex items-center gap-2"
                >
                  <div className="icon-file-text text-base"></div>
                  <span>{file.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('Sidebar component error:', error);
    return null;
  }
}
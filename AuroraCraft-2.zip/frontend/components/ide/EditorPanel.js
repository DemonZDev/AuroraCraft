function EditorPanel({ file, files, onClose }) {
  try {
    const [code, setCode] = React.useState(file?.content || '');

    React.useEffect(() => {
      setCode(file?.content || '');
    }, [file]);

    return (
      <div className="w-1/2 border-l border-[var(--border-color)] bg-[var(--bg-dark)] flex flex-col" data-name="editor-panel" data-file="components/ide/EditorPanel.js">
        <div className="p-4 border-b border-[var(--border-color)] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="icon-file-code text-lg"></div>
            <span className="font-medium">{file?.name || 'No file selected'}</span>
          </div>
          <button onClick={onClose}>
            <div className="icon-x text-lg"></div>
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
          {file ? (
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full h-full bg-[var(--bg-darker)] text-[var(--text-primary)] p-4 rounded-lg border border-[var(--border-color)] font-mono text-sm resize-none focus:outline-none focus:border-[var(--primary-color)]"
              placeholder="// Your code here..."
            />
          ) : (
            <div className="text-center py-16 text-[var(--text-secondary)]">
              Select a file from the sidebar to edit
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('EditorPanel component error:', error);
    return null;
  }
}
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg-darker)]">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-[var(--text-primary)] mb-4">Something went wrong</h1>
            <p className="text-[var(--text-secondary)] mb-4">We're sorry, but something unexpected happened.</p>
            <button onClick={() => window.location.reload()} className="btn-primary">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  try {
    const features = [
      { icon: 'message-circle', title: 'Dynamic Chat Mode', description: 'Interactive AI conversation guides you through plugin creation with clarifying questions and step-by-step assistance.' },
      { icon: 'layout-list', title: 'Plan Mode', description: 'Generate comprehensive project plans with directory structure, dependencies, and feature roadmaps before coding.' },
      { icon: 'code-2', title: 'Real-time Code Editor', description: 'Browse and edit Java, Kotlin, YAML, and config files with live AI collaboration and instant feedback.' },
      { icon: 'zap', title: 'One-Click Compilation', description: 'Maven-powered builds with Java 21 support. Get instant error feedback and AI-assisted debugging.' },
      { icon: 'sparkles', title: 'Prompt Enhancement', description: 'AI rewrites your prompts for clarity and effectiveness, teaching better communication patterns.' },
      { icon: 'database', title: 'Multi-Model Support', description: 'Choose from GPT-4, Claude 3, Gemini, DeepSeek and more. Track token usage per model and session.' }
    ];

    return (
      <div className="min-h-screen" data-name="app" data-file="app.js">
        <Header />
        <Hero />
        
        <section className="py-20 px-4 max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Powerful Features for Plugin Development</h2>
            <p className="text-[var(--text-secondary)] text-lg max-w-2xl mx-auto">
              Everything you need to build professional Minecraft plugins with AI assistance
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <FeatureCard key={index} {...feature} />
            ))}
          </div>
        </section>

        <Footer />
      </div>
    );
  } catch (error) {
    console.error('App component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="p-8 text-center">Error loading token management</div>;
    }
    return this.props.children;
  }
}

function TokenManagementApp() {
  try {
    const [users, setUsers] = React.useState([]);
    const [selectedUser, setSelectedUser] = React.useState(null);
    const [tokenAmount, setTokenAmount] = React.useState('');
    const [showAddModal, setShowAddModal] = React.useState(false);

    React.useEffect(() => {
      const user = localStorage.getItem('currentUser');
      if (!user) {
        window.location.href = 'login.html';
        return;
      }
      const userData = JSON.parse(user);
      if (userData.objectData?.role !== 'admin') {
        window.location.href = 'index.html';
        return;
      }
      loadUsers();
    }, []);

    const loadUsers = async () => {
      try {
        const result = await trickleListObjects('user', 1000, true);
        setUsers(result.items.filter(u => u.objectData.role !== 'admin'));
      } catch (error) {
        console.error('Failed to load users:', error);
      }
    };

    const handleAddTokens = async () => {
      if (!selectedUser || !tokenAmount) return;
      
      const amount = parseInt(tokenAmount);
      if (isNaN(amount) || amount <= 0) {
        alert('Please enter a valid token amount');
        return;
      }

      const result = await tokenManager.addTokens(selectedUser.objectId, amount, 'admin_grant');
      if (result.success) {
        alert(`Successfully added ${amount} tokens to ${selectedUser.objectData.username}`);
        setShowAddModal(false);
        setSelectedUser(null);
        setTokenAmount('');
        loadUsers();
      } else {
        alert('Failed to add tokens: ' + result.error);
      }
    };

    return (
      <div className="min-h-screen" data-name="token-management-app" data-file="admin-tokens-app.js">
        <Header />
        
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">Token Management</h1>
              <p className="text-[var(--text-secondary)]">Manage user token balances</p>
            </div>
            <button onClick={() => window.location.href = 'admin.html'} className="px-4 py-2 bg-[var(--secondary-color)] rounded-lg">
              Back to Admin
            </button>
          </div>

          <div className="space-y-4">
            {users.map(user => (
              <div key={user.objectId} className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center">
                      <div className="icon-user text-xl text-white"></div>
                    </div>
                    <div>
                      <h3 className="font-bold">{user.objectData.username}</h3>
                      <p className="text-sm text-[var(--text-secondary)]">{user.objectData.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="flex items-center gap-2 text-yellow-400">
                        <div className="icon-coins text-xl"></div>
                        <span className="text-2xl font-bold">{user.objectData.tokens || 0}</span>
                      </div>
                      <p className="text-xs text-[var(--text-secondary)]">Total used: {user.objectData.totalTokensUsed || 0}</p>
                    </div>
                    <button
                      onClick={() => {setSelectedUser(user); setShowAddModal(true);}}
                      className="px-4 py-2 bg-[var(--primary-color)] rounded-lg"
                    >
                      Add Tokens
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {showAddModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => setShowAddModal(false)}>
            <div className="bg-[var(--bg-dark)] rounded-xl p-6 max-w-md w-full mx-4 border border-[var(--border-color)]" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-xl font-bold mb-4">Add Tokens</h3>
              <p className="text-[var(--text-secondary)] mb-4">User: {selectedUser?.objectData.username}</p>
              <input
                type="number"
                value={tokenAmount}
                onChange={(e) => setTokenAmount(e.target.value)}
                placeholder="Enter token amount"
                className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg mb-4"
              />
              <div className="flex gap-2">
                <button onClick={handleAddTokens} className="flex-1 px-4 py-3 bg-[var(--primary-color)] rounded-lg">
                  Add Tokens
                </button>
                <button onClick={() => {setShowAddModal(false); setSelectedUser(null); setTokenAmount('');}} className="flex-1 px-4 py-3 bg-[var(--secondary-color)] rounded-lg">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('TokenManagementApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><TokenManagementApp /></ErrorBoundary>);
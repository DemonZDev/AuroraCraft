class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="p-8 text-center">Error loading registration</div>;
    }
    return this.props.children;
  }
}

function RegisterApp() {
  try {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" data-name="register-app" data-file="register-app.js">
        <RegisterForm />
      </div>
    );
  } catch (error) {
    console.error('RegisterApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><RegisterApp /></ErrorBoundary>);
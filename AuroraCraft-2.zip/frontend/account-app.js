class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="p-8 text-center">Error loading account settings</div>;
    }
    return this.props.children;
  }
}

function AccountApp() {
  try {
    const [user, setUser] = React.useState(null);
    const [formData, setFormData] = React.useState({username: '', email: ''});
    const [passwordData, setPasswordData] = React.useState({oldPassword: '', newPassword: '', confirmPassword: ''});
    const [avatar, setAvatar] = React.useState(null);
    const [avatarPreview, setAvatarPreview] = React.useState(null);
    const fileInputRef = React.useRef(null);

    React.useEffect(() => {
      const userData = localStorage.getItem('currentUser');
      if (!userData) {
        window.location.href = 'login.html';
        return;
      }
      const parsed = JSON.parse(userData);
      setUser(parsed);
      setFormData({username: parsed.objectData.username, email: parsed.objectData.email});
      if (parsed.objectData.avatar) {
        setAvatarPreview(parsed.objectData.avatar);
      }
    }, []);

    const handleAvatarChange = (e) => {
      const file = e.target.files[0];
      if (file) {
        if (file.size > 5 * 1024 * 1024) {
          alert('File size must be less than 5MB');
          return;
        }
        setAvatar(file);
        const reader = new FileReader();
        reader.onloadend = () => setAvatarPreview(reader.result);
        reader.readAsDataURL(file);
      }
    };

    const updateProfile = async () => {
      try {
        await trickleUpdateObject('user', user.objectId, {
          ...user.objectData,
          username: formData.username,
          email: formData.email,
          avatar: avatarPreview
        });
        const updated = await trickleGetObject('user', user.objectId);
        localStorage.setItem('currentUser', JSON.stringify(updated));
        setUser(updated);
        alert('Profile updated successfully');
      } catch (error) {
        alert('Failed to update profile');
      }
    };

    const changePassword = async () => {
      if (passwordData.oldPassword !== user.objectData.password) {
        alert('Old password is incorrect');
        return;
      }
      if (passwordData.newPassword.length < 6) {
        alert('New password must be at least 6 characters');
        return;
      }
      if (passwordData.newPassword !== passwordData.confirmPassword) {
        alert('Passwords do not match');
        return;
      }
      try {
        await trickleUpdateObject('user', user.objectId, {
          ...user.objectData,
          password: passwordData.newPassword
        });
        setPasswordData({oldPassword: '', newPassword: '', confirmPassword: ''});
        alert('Password changed successfully');
      } catch (error) {
        alert('Failed to change password');
      }
    };

    if (!user) return null;

    return (
      <div className="min-h-screen" data-name="account-app" data-file="account-app.js">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-12">
          <h1 className="text-3xl font-bold mb-8">Account Settings</h1>
          
          <div className="space-y-6">
            <div className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Profile Information</h3>
              <div className="flex items-center gap-6 mb-6">
                <div className="relative">
                  <div className="w-24 h-24 bg-[var(--secondary-color)] rounded-full flex items-center justify-center overflow-hidden">
                    {avatarPreview ? (
                      <img src={avatarPreview} alt="Avatar" className="w-full h-full object-cover" />
                    ) : (
                      <div className="icon-user text-4xl text-white"></div>
                    )}
                  </div>
                  <button onClick={() => fileInputRef.current?.click()} className="absolute bottom-0 right-0 w-8 h-8 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                    <div className="icon-camera text-sm text-white"></div>
                  </button>
                  <input ref={fileInputRef} type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)] mb-1">Upload your avatar (max 5MB)</p>
                  <p className="text-xs text-[var(--text-secondary)]">Supported formats: JPG, PNG, GIF</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm mb-2">Username</label>
                  <input value={formData.username} onChange={(e) => setFormData({...formData, username: e.target.value})} className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                </div>
                <div>
                  <label className="block text-sm mb-2">Email</label>
                  <input type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                </div>
              </div>
              <button onClick={updateProfile} className="mt-4 px-6 py-3 bg-[var(--primary-color)] rounded-lg">Save Changes</button>
            </div>

            <div className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Change Password</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm mb-2">Old Password</label>
                  <input type="password" value={passwordData.oldPassword} onChange={(e) => setPasswordData({...passwordData, oldPassword: e.target.value})} className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                </div>
                <div>
                  <label className="block text-sm mb-2">New Password</label>
                  <input type="password" value={passwordData.newPassword} onChange={(e) => setPasswordData({...passwordData, newPassword: e.target.value})} className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                </div>
                <div>
                  <label className="block text-sm mb-2">Confirm New Password</label>
                  <input type="password" value={passwordData.confirmPassword} onChange={(e) => setPasswordData({...passwordData, confirmPassword: e.target.value})} className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg" />
                </div>
              </div>
              <button onClick={changePassword} className="mt-4 px-6 py-3 bg-[var(--primary-color)] rounded-lg">Update Password</button>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('AccountApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><AccountApp /></ErrorBoundary>);
# 🔐 AuroraCraft Admin Credentials

## Admin Account

**Email:** `admin@auroracraft.com`  
**Password:** `AuroraAdmin2024!`  
**Role:** Administrator  
**Tokens:** 1,000,000 (unlimited for admin use)

---

## Access URLs

- **Homepage:** http://localhost:3000/
- **Login Page:** http://localhost:3000/login.html
- **Admin Dashboard:** http://localhost:3000/admin.html
- **Sessions Manager:** http://localhost:3000/sessions.html
- **Account Settings:** http://localhost:3000/account.html

---

## Admin Capabilities

As an administrator, you have full access to:

✅ **User Management**
- View all users
- Update user token balances
- Manage user roles
- View user activity

✅ **AI Provider Management**
- Add/edit/delete AI providers
- Configure API keys
- Set provider status (active/inactive)
- Configure authentication methods

✅ **AI Model Management**
- Add/edit/delete AI models
- Set model parameters
- Configure token costs
- Assign tags (Recommended, Fast, Budget, etc.)
- Link models to providers

✅ **Token Management**
- View all token transactions
- Adjust user token balances
- Monitor system-wide token usage

✅ **System Settings**
- Configure global settings
- Set tokens per context interval
- Manage system configurations

---

## Test User Account (For Testing)

**Email:** `test@example.com`  
**Password:** `test123`  
**Role:** User  
**Tokens:** 9,999.5

---

## API Endpoints (For Development)

**Base URL:** http://localhost:8001/api

**Authentication Required:**
```bash
# Login to get token
curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@auroracraft.com", "password": "AuroraAdmin2024!"}'

# Use token in subsequent requests
curl -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  http://localhost:8001/api/users
```

---

## Security Notes

⚠️ **IMPORTANT:**
- Change the admin password after first login
- Keep credentials secure and private
- The Google API key is configured in `/app/backend/.env`
- MongoDB connection string is in `/app/backend/.env`

---

## Services Status

Check if all services are running:
```bash
sudo supervisorctl status
```

Services:
- ✅ Backend (FastAPI) - Port 8001
- ✅ Frontend (Static) - Port 3000  
- ✅ MongoDB - Port 27017
- ✅ Nginx Proxy

---

Created: 2025-11-17

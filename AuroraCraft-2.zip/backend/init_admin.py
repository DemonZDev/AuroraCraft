#!/usr/bin/env python3
from pymongo import MongoClient
from passlib.context import CryptContext
import uuid
from datetime import datetime
import os
from dotenv import load_dotenv

load_dotenv()

MONGO_URL = os.getenv("MONGO_URL")
client = MongoClient(MONGO_URL)
db = client.auroracraft

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Check if admin exists
admin = db.users.find_one({"email": "admin@auroracraft.com"})

if not admin:
    admin_id = str(uuid.uuid4())
    db.users.insert_one({
        "_id": admin_id,
        "username": "admin",
        "email": "admin@auroracraft.com",
        "password": pwd_context.hash("AuroraAdmin2024!"),
        "role": "admin",
        "tokens": 1000000,
        "totalTokensUsed": 0,
        "createdAt": datetime.utcnow()
    })
    print("✅ Admin account created successfully!")
    print("\n" + "="*50)
    print("🔐 ADMIN CREDENTIALS")
    print("="*50)
    print(f"Email: admin@auroracraft.com")
    print(f"Password: AuroraAdmin2024!")
    print("="*50 + "\n")
else:
    print("ℹ️  Admin account already exists")
    print("\n" + "="*50)
    print("🔐 ADMIN CREDENTIALS")
    print("="*50)
    print(f"Email: admin@auroracraft.com")
    print(f"Password: AuroraAdmin2024!")
    print("="*50 + "\n")

client.close()

function LoginForm() {
  try {
    const [formData, setFormData] = React.useState({
      email: '',
      password: ''
    });
    const [errors, setErrors] = React.useState({});
    const [isLoading, setIsLoading] = React.useState(false);

    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData(prev => ({ ...prev, [name]: value }));
      if (errors[name]) {
        setErrors(prev => ({ ...prev, [name]: '' }));
      }
    };

    const handleSubmit = async (e) => {
      e.preventDefault();
      const validationErrors = validateLoginForm(formData);
      
      if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        return;
      }

      setIsLoading(true);
      try {
        const users = await trickleListObjects('user', 100, true);
        const user = users.items.find(u => 
          u.objectData.email === formData.email && 
          u.objectData.password === formData.password
        );

        if (user) {
          localStorage.setItem('currentUser', JSON.stringify(user));
          window.location.href = 'ide.html';
        } else {
          setErrors({ submit: 'Invalid email or password' });
        }
      } catch (error) {
        setErrors({ submit: 'Login failed. Please try again.' });
      } finally {
        setIsLoading(false);
      }
    };

    return (
      <div className="w-full max-w-md bg-[var(--bg-dark)] rounded-xl p-8 border border-[var(--border-color)]" data-name="login-form" data-file="components/auth/LoginForm.js">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[var(--primary-color)] rounded-xl flex items-center justify-center mx-auto mb-4">
            <div className="icon-sparkles text-3xl text-white"></div>
          </div>
          <h1 className="text-2xl font-bold mb-2">Welcome Back</h1>
          <p className="text-[var(--text-secondary)] text-sm">Login to continue building</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              placeholder="Enter email"
            />
            {errors.email && <p className="text-red-400 text-sm mt-1">{errors.email}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              placeholder="Enter password"
            />
            {errors.password && <p className="text-red-400 text-sm mt-1">{errors.password}</p>}
          </div>

          {errors.submit && <p className="text-red-400 text-sm">{errors.submit}</p>}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-[var(--primary-color)] rounded-lg font-medium hover:bg-[var(--accent-color)] transition-all disabled:opacity-50"
          >
            {isLoading ? 'Logging in...' : 'Login'}
          </button>
        </form>

        <p className="text-center text-sm text-[var(--text-secondary)] mt-6">
          Don't have an account? <a href="register.html" className="text-[var(--primary-color)] hover:underline">Register</a>
        </p>
      </div>
    );
  } catch (error) {
    console.error('LoginForm error:', error);
    return null;
  }
}
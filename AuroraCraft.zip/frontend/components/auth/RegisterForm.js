function RegisterForm() {
  try {
    const [formData, setFormData] = React.useState({
      username: '',
      email: '',
      password: '',
      confirmPassword: ''
    });
    const [errors, setErrors] = React.useState({});
    const [isLoading, setIsLoading] = React.useState(false);
    const [avatar, setAvatar] = React.useState(null);
    const [avatarPreview, setAvatarPreview] = React.useState(null);
    const fileInputRef = React.useRef(null);

    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData(prev => ({ ...prev, [name]: value }));
      if (errors[name]) {
        setErrors(prev => ({ ...prev, [name]: '' }));
      }
    };

    const handleAvatarChange = (e) => {
      const file = e.target.files[0];
      if (file) {
        if (file.size > 5 * 1024 * 1024) {
          alert('Avatar file size must be less than 5MB');
          return;
        }
        setAvatar(file);
        const reader = new FileReader();
        reader.onloadend = () => setAvatarPreview(reader.result);
        reader.readAsDataURL(file);
      }
    };

    const handleSubmit = async (e) => {
      e.preventDefault();
      const validationErrors = validateRegisterForm(formData);
      
      if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        return;
      }

      setIsLoading(true);
      try {
        const users = await trickleListObjects('user', 1, true);
        const isFirstUser = users.items.length === 0;
        
        await trickleCreateObject('user', {
          username: formData.username,
          email: formData.email,
          password: formData.password,
          role: isFirstUser ? 'admin' : 'user',
          tokens: 100,
          totalTokensUsed: 0,
          avatar: avatarPreview || null
        });
        window.location.href = 'login.html';
      } catch (error) {
        setErrors({ submit: 'Registration failed. Please try again.' });
      } finally {
        setIsLoading(false);
      }
    };

    return (
      <div className="w-full max-w-md bg-[var(--bg-dark)] rounded-xl p-8 border border-[var(--border-color)]" data-name="register-form" data-file="components/auth/RegisterForm.js">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[var(--primary-color)] rounded-xl flex items-center justify-center mx-auto mb-4">
            <div className="icon-sparkles text-3xl text-white"></div>
          </div>
          <h1 className="text-2xl font-bold mb-2">Create Account</h1>
          <p className="text-[var(--text-secondary)] text-sm">Join AuroraCraft today</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex flex-col items-center mb-6">
            <div className="relative mb-3">
              <div className="w-24 h-24 bg-[var(--secondary-color)] rounded-full flex items-center justify-center overflow-hidden">
                {avatarPreview ? (
                  <img src={avatarPreview} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <div className="icon-user text-4xl text-white"></div>
                )}
              </div>
              <button type="button" onClick={() => fileInputRef.current?.click()} className="absolute bottom-0 right-0 w-8 h-8 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                <div className="icon-camera text-sm text-white"></div>
              </button>
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
            </div>
            <p className="text-xs text-[var(--text-secondary)]">Optional: Upload avatar (max 5MB)</p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Username</label>
            <input
              type="text"
              name="username"
              value={formData.username}
              onChange={handleChange}
              className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              placeholder="Enter username"
            />
            {errors.username && <p className="text-red-400 text-sm mt-1">{errors.username}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              placeholder="Enter email"
            />
            {errors.email && <p className="text-red-400 text-sm mt-1">{errors.email}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              placeholder="Enter password"
            />
            {errors.password && <p className="text-red-400 text-sm mt-1">{errors.password}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Confirm Password</label>
            <input
              type="password"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              placeholder="Confirm password"
            />
            {errors.confirmPassword && <p className="text-red-400 text-sm mt-1">{errors.confirmPassword}</p>}
          </div>

          {errors.submit && <p className="text-red-400 text-sm">{errors.submit}</p>}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-[var(--primary-color)] rounded-lg font-medium hover:bg-[var(--accent-color)] transition-all disabled:opacity-50"
          >
            {isLoading ? 'Creating Account...' : 'Register'}
          </button>
        </form>

        <p className="text-center text-sm text-[var(--text-secondary)] mt-6">
          Already have an account? <a href="login.html" className="text-[var(--primary-color)] hover:underline">Login</a>
        </p>
      </div>
    );
  } catch (error) {
    console.error('RegisterForm error:', error);
    return null;
  }
}
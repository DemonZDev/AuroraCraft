class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="p-8 text-center">Error loading sessions</div>;
    }
    return this.props.children;
  }
}

function SessionsApp() {
  try {
    const [sessions, setSessions] = React.useState([]);
    const [isLoading, setIsLoading] = React.useState(true);
    const [currentUser, setCurrentUser] = React.useState(null);
    const [selectedSessions, setSelectedSessions] = React.useState([]);
    const [showDeleteModal, setShowDeleteModal] = React.useState(false);
    const [sessionToDelete, setSessionToDelete] = React.useState(null);
    const [showRenameModal, setShowRenameModal] = React.useState(false);
    const [sessionToRename, setSessionToRename] = React.useState(null);
    const [newSessionName, setNewSessionName] = React.useState('');
    const [showUploadModal, setShowUploadModal] = React.useState(false);
    const [sessionForUpload, setSessionForUpload] = React.useState(null);
    const [selectedFiles, setSelectedFiles] = React.useState([]);
    const [uploadPath, setUploadPath] = React.useState('');
    const fileUploadRef = React.useRef(null);

    React.useEffect(() => {
      const user = localStorage.getItem('currentUser');
      if (!user) {
        window.location.href = 'login.html';
        return;
      }
      setCurrentUser(JSON.parse(user));
      loadSessions(JSON.parse(user));
    }, []);

    const loadSessions = async (user) => {
      try {
        const sessionObjectType = `session:${user.objectId}`;
        const result = await trickleListObjects(sessionObjectType, 100, true);
        setSessions(result.items);
      } catch (error) {
        console.error('Failed to load sessions:', error);
      } finally {
        setIsLoading(false);
      }
    };

    const toggleSessionSelection = (sessionId) => {
      setSelectedSessions(prev => 
        prev.includes(sessionId) 
          ? prev.filter(id => id !== sessionId)
          : [...prev, sessionId]
      );
    };

    const deleteSession = async (sessionId) => {
      try {
        await trickleDeleteObject(`session:${currentUser.objectId}`, sessionId);
        loadSessions(currentUser);
        setShowDeleteModal(false);
        setSessionToDelete(null);
      } catch (error) {
        console.error('Failed to delete session:', error);
        alert('Failed to delete project');
      }
    };

    const deleteSelectedSessions = async () => {
      try {
        for (const sessionId of selectedSessions) {
          await trickleDeleteObject(`session:${currentUser.objectId}`, sessionId);
        }
        setSelectedSessions([]);
        loadSessions(currentUser);
        setShowDeleteModal(false);
      } catch (error) {
        console.error('Failed to delete sessions:', error);
        alert('Failed to delete selected projects');
      }
    };

    const renameSession = async () => {
      if (!newSessionName.trim()) {
        alert('Please enter a project name');
        return;
      }
      try {
        await trickleUpdateObject(`session:${currentUser.objectId}`, sessionToRename.objectId, {
          ...sessionToRename.objectData,
          name: newSessionName
        });
        loadSessions(currentUser);
        setShowRenameModal(false);
        setSessionToRename(null);
        setNewSessionName('');
      } catch (error) {
        console.error('Failed to rename session:', error);
        alert('Failed to rename project');
      }
    };

    const handleFileSelect = (e) => {
      const files = Array.from(e.target.files);
      setSelectedFiles(files);
      if (files.length > 0) {
        setShowUploadModal(true);
      }
    };

    const uploadFiles = async () => {
      if (selectedFiles.length === 0) {
        alert('Please select files to upload');
        return;
      }

      try {
        const session = await trickleGetObject(`session:${currentUser.objectId}`, sessionForUpload.objectId);
        const existingFiles = session.objectData.projectFiles || [];

        for (const file of selectedFiles) {
          const reader = new FileReader();
          await new Promise((resolve, reject) => {
            reader.onload = async (e) => {
              try {
                const content = e.target.result;
                let normalizedPath = uploadPath.trim();
                
                if (!normalizedPath || normalizedPath === '/') {
                  normalizedPath = '';
                } else {
                  normalizedPath = normalizedPath.replace(/^\/+|\/+$/g, '');
                  if (normalizedPath) {
                    normalizedPath = normalizedPath + '/';
                  }
                }

                const filePath = normalizedPath + file.name;
                
                existingFiles.push({
                  name: file.name,
                  path: filePath,
                  content: content,
                  uploadedAt: new Date().toISOString()
                });

                resolve();
              } catch (error) {
                reject(error);
              }
            };
            reader.onerror = reject;
            reader.readAsText(file);
          });
        }

        await trickleUpdateObject(`session:${currentUser.objectId}`, sessionForUpload.objectId, {
          ...session.objectData,
          projectFiles: existingFiles
        });

        alert(`Successfully uploaded ${selectedFiles.length} file(s)`);
        setShowUploadModal(false);
        setSelectedFiles([]);
        setUploadPath('');
        setSessionForUpload(null);
        loadSessions(currentUser);
      } catch (error) {
        console.error('Failed to upload files:', error);
        alert('Failed to upload files');
      }
    };

    if (!currentUser) {
      return null;
    }

    return (
      <div className="min-h-screen" data-name="sessions-app" data-file="sessions-app.js">
        <Header />
        
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">Your Sessions</h1>
              <p className="text-[var(--text-secondary)]">Manage your plugin development projects</p>
            </div>
            <div className="flex gap-3">
              {selectedSessions.length > 0 && (
                <button 
                  onClick={() => setShowDeleteModal(true)} 
                  className="px-4 py-2 bg-red-500 bg-opacity-20 text-red-400 rounded-lg hover:bg-opacity-30"
                >
                  Delete Selected ({selectedSessions.length})
                </button>
              )}
              <button onClick={() => window.location.href = 'ide.html'} className="px-6 py-3 bg-[var(--primary-color)] rounded-lg">
                New Session
              </button>
            </div>
          </div>

          {isLoading ? (
            <div className="text-center py-16">
              <div className="text-[var(--text-secondary)]">Loading sessions...</div>
            </div>
          ) : sessions.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mx-auto mb-4">
                <div className="icon-folder text-2xl text-[var(--primary-color)]"></div>
              </div>
              <h3 className="text-xl font-bold mb-2">No Sessions Yet</h3>
              <p className="text-[var(--text-secondary)] mb-6">Start your first plugin development session</p>
              <button onClick={() => window.location.href = 'ide.html'} className="px-6 py-3 bg-[var(--primary-color)] rounded-lg">
                Create Your First Session
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sessions.map(session => (
                <div key={session.objectId} className="relative">
                  <input
                    type="checkbox"
                    checked={selectedSessions.includes(session.objectId)}
                    onChange={() => toggleSessionSelection(session.objectId)}
                    className="absolute top-4 left-4 w-5 h-5 z-10"
                  />
                  <div className="bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-xl p-6 hover:border-[var(--primary-color)] transition-all">
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-10 h-10 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center ml-8">
                        <div className="icon-folder text-lg text-[var(--primary-color)]"></div>
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setSessionForUpload(session);
                            fileUploadRef.current?.click();
                          }}
                          className="text-[var(--text-secondary)] hover:text-green-400"
                          title="Upload files"
                        >
                          <div className="icon-upload text-base"></div>
                        </button>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setSessionToRename(session);
                            setNewSessionName(session.objectData.name || '');
                            setShowRenameModal(true);
                          }}
                          className="text-[var(--text-secondary)] hover:text-blue-400"
                          title="Rename project"
                        >
                          <div className="icon-edit text-base"></div>
                        </button>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setSessionToDelete(session);
                            setShowDeleteModal(true);
                          }}
                          className="text-[var(--text-secondary)] hover:text-red-400"
                          title="Delete project"
                        >
                          <div className="icon-trash text-base"></div>
                        </button>
                      </div>
                    </div>
                    
                    <div onClick={() => window.location.href = `ide.html?session=${session.objectId}`} className="cursor-pointer">
                      <h3 className="text-lg font-bold mb-2">{session.objectData.name || 'Untitled Session'}</h3>
                      
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2 text-[var(--text-secondary)]">
                          <div className="icon-calendar text-base"></div>
                          <span>{new Date(session.createdAt).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center gap-2 text-[var(--text-secondary)]">
                          <div className="icon-cpu text-base"></div>
                          <span>{session.objectData.model || 'GPT-4'}</span>
                        </div>
                        <div className="flex items-center gap-2 text-[var(--text-secondary)]">
                          <div className="icon-message-circle text-base"></div>
                          <span>{session.objectData.messageCount || 0} messages</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          <input
            ref={fileUploadRef}
            type="file"
            multiple
            onChange={handleFileSelect}
            className="hidden"
          />

          {showUploadModal && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => {setShowUploadModal(false); setSelectedFiles([]); setUploadPath(''); setSessionForUpload(null);}}>
              <div className="bg-[var(--bg-dark)] rounded-xl p-6 max-w-md w-full mx-4 border border-[var(--border-color)]" onClick={(e) => e.stopPropagation()}>
                <h3 className="text-xl font-bold mb-4">Upload Files</h3>
                <p className="text-sm text-[var(--text-secondary)] mb-4">
                  Selected {selectedFiles.length} file(s) for {sessionForUpload?.objectData.name || 'project'}
                </p>
                
                <div className="mb-4">
                  <label className="block text-sm font-medium mb-2">Upload Path (optional)</label>
                  <input
                    type="text"
                    value={uploadPath}
                    onChange={(e) => setUploadPath(e.target.value)}
                    placeholder="/ or blank for root, /directory_name/ for specific folder"
                    className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg"
                  />
                  <p className="text-xs text-[var(--text-secondary)] mt-2">
                    Examples: <code className="bg-[var(--bg-darker)] px-1 py-0.5 rounded">/</code> (root), 
                    <code className="bg-[var(--bg-darker)] px-1 py-0.5 rounded ml-1">/src/</code>, 
                    <code className="bg-[var(--bg-darker)] px-1 py-0.5 rounded ml-1">config/</code>
                  </p>
                </div>

                <div className="max-h-32 overflow-y-auto mb-4 p-3 bg-[var(--bg-darker)] rounded-lg">
                  {selectedFiles.map((file, index) => (
                    <div key={index} className="text-sm text-[var(--text-secondary)] flex items-center gap-2 mb-1">
                      <div className="icon-file text-xs text-[var(--primary-color)]"></div>
                      <span>{file.name}</span>
                    </div>
                  ))}
                </div>

                <div className="flex gap-3">
                  <button onClick={uploadFiles} className="flex-1 px-4 py-3 bg-[var(--primary-color)] rounded-lg">
                    Upload Files
                  </button>
                  <button 
                    onClick={() => {setShowUploadModal(false); setSelectedFiles([]); setUploadPath(''); setSessionForUpload(null);}}
                    className="flex-1 px-4 py-3 bg-[var(--secondary-color)] rounded-lg"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

          {showRenameModal && sessionToRename && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => {setShowRenameModal(false); setSessionToRename(null); setNewSessionName('');}}>
              <div className="bg-[var(--bg-dark)] rounded-xl p-6 max-w-md w-full mx-4 border border-[var(--border-color)]" onClick={(e) => e.stopPropagation()}>
                <h3 className="text-xl font-bold mb-4">Rename Project</h3>
                <input
                  type="text"
                  value={newSessionName}
                  onChange={(e) => setNewSessionName(e.target.value)}
                  placeholder="Enter new project name"
                  className="w-full px-4 py-3 bg-[var(--bg-darker)] border border-[var(--border-color)] rounded-lg mb-4"
                />
                <div className="flex gap-3">
                  <button onClick={renameSession} className="flex-1 px-4 py-3 bg-[var(--primary-color)] rounded-lg">
                    Rename
                  </button>
                  <button 
                    onClick={() => {setShowRenameModal(false); setSessionToRename(null); setNewSessionName('');}}
                    className="flex-1 px-4 py-3 bg-[var(--secondary-color)] rounded-lg"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

          {showDeleteModal && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => {setShowDeleteModal(false); setSessionToDelete(null);}}>
              <div className="bg-[var(--bg-dark)] rounded-xl p-6 max-w-md w-full mx-4 border border-[var(--border-color)]" onClick={(e) => e.stopPropagation()}>
                <h3 className="text-xl font-bold mb-4">Delete Project{selectedSessions.length > 0 ? 's' : ''}</h3>
                <p className="text-[var(--text-secondary)] mb-6">
                  {sessionToDelete 
                    ? `Are you sure you want to delete "${sessionToDelete.objectData.name || 'Untitled Project'}"? This action cannot be undone.`
                    : `Are you sure you want to delete ${selectedSessions.length} selected project${selectedSessions.length > 1 ? 's' : ''}? This action cannot be undone.`
                  }
                </p>
                <div className="flex gap-3">
                  <button 
                    onClick={() => sessionToDelete ? deleteSession(sessionToDelete.objectId) : deleteSelectedSessions()}
                    className="flex-1 px-4 py-3 bg-red-500 rounded-lg hover:bg-red-600"
                  >
                    Confirm Delete
                  </button>
                  <button 
                    onClick={() => {setShowDeleteModal(false); setSessionToDelete(null);}}
                    className="flex-1 px-4 py-3 bg-[var(--secondary-color)] rounded-lg"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    );
  } catch (error) {
    console.error('SessionsApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><SessionsApp /></ErrorBoundary>);
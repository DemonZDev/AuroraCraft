async function getActiveModels() {
  try {
    const [providersData, modelsData] = await Promise.all([
      trickleListObjects('ai_provider', 1000, true),
      trickleListObjects('ai_model', 1000, true)
    ]);
    
    const activeProviders = providersData.items.filter(p => p.objectData.Status === 'active');
    const enabledModels = modelsData.items.filter(m => m.objectData.Status === 'enabled');
    
    return enabledModels.map(model => {
      const provider = activeProviders.find(p => p.objectId === model.objectData.ProviderId);
      return {
        modelId: model.objectId,
        modelName: model.objectData.FriendlyName,
        modelIdentifier: model.objectData.ModelID,
        provider: provider ? {
          id: provider.objectId,
          name: provider.objectData.Name,
          baseUrl: provider.objectData.BaseURL,
          authType: provider.objectData.AuthType,
          apiKey: provider.objectData.APIKey,
          headers: provider.objectData.Headers,
          defaultPayload: provider.objectData.DefaultPayload
        } : null,
        cost: model.objectData.UsageCost,
        parameters: model.objectData.Parameters,
        tags: model.objectData.Tags || []
      };
    }).filter(m => m.provider);
  } catch (error) {
    console.error('Failed to load models:', error);
    return [];
  }
}

async function invokeModel(modelId, systemPrompt, userPrompt) {
  try {
    const models = await getActiveModels();
    const selectedModel = models.find(m => m.modelId === modelId);
    
    if (!selectedModel) {
      console.error('Model not found:', modelId);
      console.error('Available models:', models.map(m => ({ id: m.modelId, name: m.modelName })));
      throw new Error(`Model "${modelId}" not found. Please select a valid model from the dropdown or configure it in the Admin panel.`);
    }
    
    if (!selectedModel.provider) {
      console.error('Provider not configured for model:', selectedModel.modelName);
      throw new Error(`No provider configured for model "${selectedModel.modelName}". Please configure the provider in the Admin panel.`);
    }
    
    if (!selectedModel.provider.apiKey || selectedModel.provider.apiKey.length < 10) {
      throw new Error(`Invalid API key for provider "${selectedModel.provider.name}". Please set a valid API key in the Admin panel.`);
    }
    
    console.log('Using model:', selectedModel.modelName);
    console.log('Provider:', selectedModel.provider.name);
    console.log('Base URL:', selectedModel.provider.baseUrl);

    const headers = JSON.parse(selectedModel.provider.headers || '{}');
    headers['Content-Type'] = 'application/json';
    
    if (selectedModel.provider.authType === 'Bearer Token') {
      headers['Authorization'] = `Bearer ${selectedModel.provider.apiKey}`;
    } else if (selectedModel.provider.authType === 'API Key') {
      headers['X-API-Key'] = selectedModel.provider.apiKey;
    }

    const payload = JSON.parse(selectedModel.provider.defaultPayload || '{}');
    const params = JSON.parse(selectedModel.parameters || '{}');
    
    const requestBody = {
      ...payload,
      model: selectedModel.modelIdentifier,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      ...params
    };

    if (!selectedModel.provider.baseUrl) {
      throw new Error(`Provider base URL is not configured for "${selectedModel.provider.name}". Please configure it in the Admin panel.`);
    }
    
    const proxyUrl = `https://proxy-api.trickle-app.host/?url=${encodeURIComponent(selectedModel.provider.baseUrl)}`;
    
    console.log('=== API Request Details ===');
    console.log('Provider:', selectedModel.provider.name);
    console.log('Model:', selectedModel.modelName);
    console.log('Model Identifier:', selectedModel.modelIdentifier);
    console.log('Base URL:', selectedModel.provider.baseUrl);
    console.log('Proxy URL:', proxyUrl);
    console.log('Request body keys:', Object.keys(requestBody));
    console.log('===========================');
    
    let response;
    try {
      response = await fetch(proxyUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(requestBody)
      });
    } catch (fetchError) {
      console.error('Network error:', fetchError);
      throw new Error(`Network request failed: ${fetchError.message}\n\nPlease check:\n• Your internet connection\n• The provider's Base URL is accessible\n• No firewall is blocking the request`);
    }
    
    console.log('Response status:', response.status);

    if (!response.ok) {
      let errorMessage = `API request failed (${response.status})`;
      try {
        const errorText = await response.text();
        console.error('API error response:', errorText.substring(0, 500));
        
        if (response.status === 401 || response.status === 403) {
          errorMessage = `Authentication failed (${response.status}). Please verify your API key is correct in the Admin panel.`;
        } else if (response.status === 404) {
          errorMessage = `API endpoint not found (404). Please verify:\n• Provider Base URL: ${selectedModel.provider.baseUrl}\n• Model ID: ${selectedModel.modelIdentifier}\n\nCheck these settings in the Admin panel.`;
        } else if (response.status === 429) {
          errorMessage = `Rate limit exceeded (429). Please wait a moment and try again, or use a different model.`;
        } else if (response.status >= 500) {
          errorMessage = `Provider server error (${response.status}). The AI service may be temporarily unavailable. Try again in a moment.`;
        } else if (errorText) {
          try {
            const errorJson = JSON.parse(errorText);
            errorMessage = `API error: ${errorJson.error?.message || errorJson.message || errorText.substring(0, 100)}`;
          } catch {
            errorMessage += `\n${errorText.substring(0, 200)}`;
          }
        }
      } catch (e) {
        console.error('Could not read error response:', e);
      }
      throw new Error(errorMessage);
    }

    let responseText;
    try {
      responseText = await response.text();
    } catch (e) {
      console.error('Failed to read response:', e);
      throw new Error('Failed to read API response. Please try again.');
    }

    console.log('Raw response (first 200 chars):', responseText.substring(0, 200));

    if (!responseText || responseText.trim().length === 0) {
      throw new Error('Empty response from API. The model may not have generated any content.');
    }

    const trimmedResponse = responseText.trim();

    if (trimmedResponse.startsWith('<!DOCTYPE') || trimmedResponse.startsWith('<html') || trimmedResponse.startsWith('<HTML')) {
      console.error('Received HTML instead of JSON:', responseText.substring(0, 300));
      throw new Error(`API returned HTML instead of JSON. This usually means:\n• The Base URL is incorrect (current: ${selectedModel.provider.baseUrl})\n• The endpoint path is missing or wrong\n• Authentication failed\n• The API service is down\n\nPlease check the provider configuration in the Admin panel.`);
    }

    if (!trimmedResponse.startsWith('{') && !trimmedResponse.startsWith('[')) {
      console.error('Non-JSON response:', responseText.substring(0, 300));
      throw new Error(`API returned invalid response format. Expected JSON but received: ${trimmedResponse.substring(0, 100)}...`);
    }

    let data;
    try {
      data = JSON.parse(responseText);
    } catch (parseError) {
      console.error('JSON parse error:', parseError);
      console.error('Response text (first 500 chars):', responseText.substring(0, 500));
      throw new Error(`Failed to parse API response as JSON.\n\nError: ${parseError.message}\n\nResponse preview: ${trimmedResponse.substring(0, 200)}...`);
    }

    const content = data.choices?.[0]?.message?.content || 
                    data.content || 
                    data.response || 
                    data.text ||
                    data.message?.content;
                    
    if (!content) {
      console.error('Unexpected response structure:', JSON.stringify(data).substring(0, 300));
      throw new Error('No valid content found in API response. The response structure may be incompatible.');
    }

    console.log('Successfully received response');
    return content;
  } catch (error) {
    console.error('Model invocation error:', error);
    throw error;
  }
}

from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pymongo import MongoClient
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext
import os
from dotenv import load_dotenv
import httpx
import json
import uuid

load_dotenv()

app = FastAPI(title="AuroraCraft API")

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# MongoDB Setup
MONGO_URL = os.getenv("MONGO_URL")
client = MongoClient(MONGO_URL)
db = client.auroracraft

# Security
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()
SECRET_KEY = os.getenv("JWT_SECRET", "aurora-craft-secret-key-2024")
ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("JWT_EXPIRE_MINUTES", "10080"))
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

# Pydantic Models
class UserCreate(BaseModel):
    username: str
    email: str
    password: str

class UserLogin(BaseModel):
    email: str
    password: str

class TokenUpdate(BaseModel):
    tokens: int

class SessionCreate(BaseModel):
    title: str
    mode: str
    software: str
    modelId: str

class MessageCreate(BaseModel):
    content: str
    role: str

class AIRequest(BaseModel):
    systemPrompt: str
    userPrompt: str
    modelId: Optional[str] = None

class ProviderCreate(BaseModel):
    Name: str
    BaseURL: str
    AuthType: str
    Headers: Optional[str] = "{}"
    DefaultPayload: Optional[str] = "{}"
    HealthCheckEndpoint: Optional[str] = ""
    Status: str = "active"
    APIKey: Optional[str] = ""

class ModelCreate(BaseModel):
    ProviderId: str
    ModelID: str
    FriendlyName: str
    UsageCost: float = 0.0
    Status: str = "enabled"
    PromptFormat: Optional[str] = ""
    Parameters: Optional[str] = "{}"
    Tags: List[str] = []
    TokensPerContext: int = 1000
    TokenAmount: float = 1.0

# Helper Functions
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
        user = db.users.find_one({"_id": user_id})
        if user is None:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")

# Initialize Default AI Provider and Model
def initialize_defaults():
    # Check if Google provider exists
    google_provider = db.ai_providers.find_one({"Name": "Google AI Studio"})
    if not google_provider:
        provider_id = str(uuid.uuid4())
        db.ai_providers.insert_one({
            "_id": provider_id,
            "Name": "Google AI Studio",
            "BaseURL": "https://generativelanguage.googleapis.com/v1beta/models",
            "AuthType": "API Key",
            "Headers": "{}",
            "DefaultPayload": "{}",
            "HealthCheckEndpoint": "",
            "Status": "active",
            "APIKey": GOOGLE_API_KEY,
            "createdAt": datetime.utcnow()
        })
        
        # Add Gemini models
        models = [
            {
                "_id": str(uuid.uuid4()),
                "ProviderId": provider_id,
                "ModelID": "gemini-2.5-pro",
                "FriendlyName": "Gemini 2.5 Pro",
                "UsageCost": 0.0,
                "Status": "enabled",
                "PromptFormat": "",
                "Parameters": '{"temperature": 0.7, "maxOutputTokens": 8192}',
                "Tags": ["Recommended"],
                "TokensPerContext": 1000,
                "TokenAmount": 1.5,
                "createdAt": datetime.utcnow()
            },
            {
                "_id": str(uuid.uuid4()),
                "ProviderId": provider_id,
                "ModelID": "gemini-2.5-flash",
                "FriendlyName": "Gemini 2.5 Flash",
                "UsageCost": 0.0,
                "Status": "enabled",
                "PromptFormat": "",
                "Parameters": '{"temperature": 0.7, "maxOutputTokens": 8192}',
                "Tags": ["Recommended", "Fast"],
                "TokensPerContext": 1000,
                "TokenAmount": 1.0,
                "createdAt": datetime.utcnow()
            },
            {
                "_id": str(uuid.uuid4()),
                "ProviderId": provider_id,
                "ModelID": "gemini-2.5-flash-lite",
                "FriendlyName": "Gemini 2.5 Flash Lite",
                "UsageCost": 0.0,
                "Status": "enabled",
                "PromptFormat": "",
                "Parameters": '{"temperature": 0.7, "maxOutputTokens": 8192}',
                "Tags": ["Fast", "Budget"],
                "TokensPerContext": 1000,
                "TokenAmount": 0.5,
                "createdAt": datetime.utcnow()
            }
        ]
        db.ai_models.insert_many(models)
        print("✅ Initialized Google Gemini AI provider and models")
    
    # Initialize system settings
    settings = db.system_settings.find_one()
    if not settings:
        db.system_settings.insert_one({
            "_id": str(uuid.uuid4()),
            "TokensPerContextInterval": 10,
            "createdAt": datetime.utcnow()
        })
        print("✅ Initialized system settings")

@app.on_event("startup")
async def startup_event():
    initialize_defaults()
    print("🚀 AuroraCraft API Started")
    print(f"📦 MongoDB Connected: {MONGO_URL[:30]}...")
    print(f"🔑 Google API Key Configured: {GOOGLE_API_KEY[:20]}...")

# Health Check
@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}

# Auth Endpoints
@app.post("/api/auth/register")
async def register(user: UserCreate):
    # Check if user exists
    existing_user = db.users.find_one({"email": user.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Create user
    user_id = str(uuid.uuid4())
    db.users.insert_one({
        "_id": user_id,
        "username": user.username,
        "email": user.email,
        "password": hash_password(user.password),
        "role": "user",
        "tokens": 10000,
        "totalTokensUsed": 0,
        "createdAt": datetime.utcnow()
    })
    
    # Create token
    access_token = create_access_token(data={"sub": user_id})
    
    return {
        "token": access_token,
        "user": {
            "id": user_id,
            "username": user.username,
            "email": user.email,
            "role": "user",
            "tokens": 10000
        }
    }

@app.post("/api/auth/login")
async def login(credentials: UserLogin):
    user = db.users.find_one({"email": credentials.email})
    if not user or not verify_password(credentials.password, user["password"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    access_token = create_access_token(data={"sub": user["_id"]})
    
    return {
        "token": access_token,
        "user": {
            "id": user["_id"],
            "username": user["username"],
            "email": user["email"],
            "role": user["role"],
            "tokens": user["tokens"]
        }
    }

@app.get("/api/auth/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    return {
        "id": current_user["_id"],
        "username": current_user["username"],
        "email": current_user["email"],
        "role": current_user["role"],
        "tokens": current_user["tokens"],
        "totalTokensUsed": current_user.get("totalTokensUsed", 0)
    }

# User Management
@app.get("/api/users")
async def list_users(current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    users = list(db.users.find({}, {"password": 0}))
    return {"items": users, "total": len(users)}

@app.put("/api/users/{user_id}/tokens")
async def update_user_tokens(user_id: str, token_update: TokenUpdate, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    result = db.users.update_one(
        {"_id": user_id},
        {"$set": {"tokens": token_update.tokens}}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {"success": True}

@app.put("/api/users/{user_id}")
async def update_user(user_id: str, updates: dict, current_user: dict = Depends(get_current_user)):
    if current_user["_id"] != user_id and current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Unauthorized")
    
    # Remove sensitive fields
    updates.pop("password", None)
    updates.pop("_id", None)
    
    result = db.users.update_one({"_id": user_id}, {"$set": updates})
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    updated_user = db.users.find_one({"_id": user_id}, {"password": 0})
    return updated_user

# AI Providers
@app.get("/api/providers")
async def list_providers(current_user: dict = Depends(get_current_user)):
    providers = list(db.ai_providers.find({}))
    return {"items": providers, "total": len(providers)}

@app.post("/api/providers")
async def create_provider(provider: ProviderCreate, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    provider_id = str(uuid.uuid4())
    db.ai_providers.insert_one({
        "_id": provider_id,
        **provider.dict(),
        "createdAt": datetime.utcnow()
    })
    
    return {"id": provider_id, "success": True}

@app.put("/api/providers/{provider_id}")
async def update_provider(provider_id: str, updates: dict, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    result = db.ai_providers.update_one({"_id": provider_id}, {"$set": updates})
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Provider not found")
    
    return {"success": True}

@app.delete("/api/providers/{provider_id}")
async def delete_provider(provider_id: str, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    result = db.ai_providers.delete_one({"_id": provider_id})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Provider not found")
    
    return {"success": True}

# AI Models
@app.get("/api/models")
async def list_models(current_user: dict = Depends(get_current_user)):
    models = list(db.ai_models.find({}))
    providers = list(db.ai_providers.find({}))
    
    # Enrich models with provider info
    for model in models:
        provider = next((p for p in providers if p["_id"] == model["ProviderId"]), None)
        model["provider"] = provider
    
    return {"items": models, "total": len(models)}

@app.post("/api/models")
async def create_model(model: ModelCreate, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    model_id = str(uuid.uuid4())
    db.ai_models.insert_one({
        "_id": model_id,
        **model.dict(),
        "createdAt": datetime.utcnow()
    })
    
    return {"id": model_id, "success": True}

@app.put("/api/models/{model_id}")
async def update_model(model_id: str, updates: dict, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    result = db.ai_models.update_one({"_id": model_id}, {"$set": updates})
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Model not found")
    
    return {"success": True}

@app.delete("/api/models/{model_id}")
async def delete_model(model_id: str, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    result = db.ai_models.delete_one({"_id": model_id})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Model not found")
    
    return {"success": True}

# AI Invocation
@app.post("/api/ai/invoke")
async def invoke_ai(request: AIRequest, current_user: dict = Depends(get_current_user)):
    try:
        # Get model
        model = db.ai_models.find_one({"_id": request.modelId})
        if not model:
            raise HTTPException(status_code=404, detail="Model not found")
        
        # Get provider
        provider = db.ai_providers.find_one({"_id": model["ProviderId"]})
        if not provider:
            raise HTTPException(status_code=404, detail="Provider not found")
        
        # Check tokens
        if current_user["tokens"] < model["TokenAmount"]:
            raise HTTPException(status_code=402, detail="Insufficient tokens")
        
        # Prepare request for Google Gemini
        model_endpoint = f"{provider['BaseURL']}/{model['ModelID']}:generateContent"
        
        headers = {
            "Content-Type": "application/json"
        }
        
        # Google uses API key in URL
        params = {"key": provider["APIKey"]}
        
        request_body = {
            "contents": [
                {
                    "parts": [
                        {"text": f"{request.systemPrompt}\n\n{request.userPrompt}"}
                    ]
                }
            ],
            "generationConfig": json.loads(model.get("Parameters", "{}"))
        }
        
        # Make request
        async with httpx.AsyncClient(timeout=120.0) as http_client:
            response = await http_client.post(
                model_endpoint,
                json=request_body,
                headers=headers,
                params=params
            )
        
        if response.status_code != 200:
            error_text = response.text
            print(f"API Error: {response.status_code} - {error_text}")
            raise HTTPException(status_code=response.status_code, detail=f"AI API error: {error_text}")
        
        result = response.json()
        
        # Extract content from Gemini response
        content = result.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
        
        if not content:
            raise HTTPException(status_code=500, detail="No content in AI response")
        
        # Deduct tokens
        db.users.update_one(
            {"_id": current_user["_id"]},
            {
                "$inc": {
                    "tokens": -model["TokenAmount"],
                    "totalTokensUsed": model["TokenAmount"]
                }
            }
        )
        
        # Log transaction
        db.token_transactions.insert_one({
            "_id": str(uuid.uuid4()),
            "userId": current_user["_id"],
            "modelId": model["_id"],
            "tokensUsed": model["TokenAmount"],
            "transactionType": "usage",
            "createdAt": datetime.utcnow()
        })
        
        return {"content": content, "tokensUsed": model["TokenAmount"]}
        
    except Exception as e:
        print(f"AI Invocation Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Sessions
@app.get("/api/sessions")
async def list_sessions(current_user: dict = Depends(get_current_user)):
    sessions = list(db.sessions.find({"userId": current_user["_id"]}).sort("updatedAt", -1))
    return {"items": sessions, "total": len(sessions)}

@app.post("/api/sessions")
async def create_session(session: SessionCreate, current_user: dict = Depends(get_current_user)):
    session_id = str(uuid.uuid4())
    db.sessions.insert_one({
        "_id": session_id,
        "userId": current_user["_id"],
        "title": session.title,
        "mode": session.mode,
        "software": session.software,
        "modelId": session.modelId,
        "messages": [],
        "files": {},
        "createdAt": datetime.utcnow(),
        "updatedAt": datetime.utcnow()
    })
    
    return {"id": session_id, "success": True}

@app.get("/api/sessions/{session_id}")
async def get_session(session_id: str, current_user: dict = Depends(get_current_user)):
    session = db.sessions.find_one({"_id": session_id, "userId": current_user["_id"]})
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session

@app.put("/api/sessions/{session_id}")
async def update_session(session_id: str, updates: dict, current_user: dict = Depends(get_current_user)):
    result = db.sessions.update_one(
        {"_id": session_id, "userId": current_user["_id"]},
        {"$set": {**updates, "updatedAt": datetime.utcnow()}}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return {"success": True}

@app.delete("/api/sessions/{session_id}")
async def delete_session(session_id: str, current_user: dict = Depends(get_current_user)):
    result = db.sessions.delete_one({"_id": session_id, "userId": current_user["_id"]})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return {"success": True}

# Token Transactions
@app.get("/api/transactions")
async def list_transactions(current_user: dict = Depends(get_current_user)):
    if current_user["role"] == "admin":
        transactions = list(db.token_transactions.find({}).sort("createdAt", -1).limit(100))
    else:
        transactions = list(db.token_transactions.find({"userId": current_user["_id"]}).sort("createdAt", -1).limit(50))
    
    return {"items": transactions, "total": len(transactions)}

# System Settings
@app.get("/api/settings")
async def get_settings(current_user: dict = Depends(get_current_user)):
    settings = db.system_settings.find_one()
    return settings if settings else {"TokensPerContextInterval": 10}

@app.put("/api/settings")
async def update_settings(updates: dict, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    result = db.system_settings.update_one({}, {"$set": updates}, upsert=True)
    return {"success": True}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
